<?php

namespace SaboExtensions\SaboAttemptLimiter;

use \Attribute;
use Exception;
use Sabo\Config\SaboConfig;
use Sabo\Config\SaboConfigAttributes;
use SaboAttemptLimiterExceptionConfig;
use TypeError;

/**
 * gestionnaire de limitation d'appel de méthode
 */
#[Attribute]
class SaboAttemptLimitable{
    /**
     * si les données ont bien été confiugré
     */
    private bool $successfulyConfigured;

    /**
     * nombre de tentatives authorisés
     */
    private int $countOfAuthorizedTry;

    /**
     * temps de blocage en secondes
     */
    private int $blockTime;

    /**
     * si la réussite de la fonction rafraichi les données de blocage 
     */
    private bool $resetOnSuccess;

    /**
     * moyens de vérifications de réussite
     */
    private array $successTypes;

    /**
     * @attention toute utilisation de l'attribut mal configuré sur les callable renverra une exception en mode debug et annulera la limitation en mode production
     * @param callable|int $countOfTryAccesser un callable renvoyant un entier représentant le nombre de tentatives authorisés ou le nombre de tentatives
     * @param callable|int $blockTimeAccesser un callable renvoyant un entier représentant le nombre de temps de blocage d'accès à la méthode en secondes ou le nombre de temps
     * @param callable|bool $resetOnFuncSuccessAccesser un callable renvoyant un booléen représentant si la réussite de la fonction re authorise l'appel avant le temps de blocage ou le booléen l'indiquant directement
     * @param array $successTypes un tableau de @SaboAttemptLimiterType représentant les types de renvoyé par la fonction si elle réussie, peut contenir également un callable booleen prenant le résultat de la fonction et renvoyant si le résultat est bon => [[Verifier::class,"verifSuccessOfMyFunc"],SaboAttemptLimiterType::NO_EXCEPTION,... ], si une des conditions est vraie alors le résultat est valide ,doit être fourni si $resetOnFuncSuccessAccesser est vrai
     */
    public function __construct(callable|int $countOfTryAccesser,callable|int $blockTimeAccesser,callable|bool $resetOnFuncSuccessAccesser,array $successTypes = []){
        try{
            $this->countOfAuthorizedTry = strtolower(gettype($countOfTryAccesser) ) === "integer" ? $countOfTryAccesser : call_user_func($countOfTryAccesser);
            $this->blockTime = strtolower(gettype($blockTimeAccesser) ) === "integer" ? $blockTimeAccesser : call_user_func($blockTimeAccesser);
            $this->resetOnSuccess = strtolower(gettype($resetOnFuncSuccessAccesser) ) === "boolean" ? $resetOnFuncSuccessAccesser : call_user_func($resetOnFuncSuccessAccesser);
            $this->successTypes = $successTypes;

            if($this->resetOnSuccess && empty($this->successTypes) ) $this->successfulyConfigured = false;

            $this->successfulyConfigured = true;
        }
        catch(TypeError|Exception $e){
            $this->successfulyConfigured = false;

            if(SaboConfig::getBoolConfig(SaboConfigAttributes::DEBUG_MODE) ) throw new $e;
        }
    }

    /**
     * @return bool si l'attribut est bien configuré
     */
    public function getSuccessfulyConfigured():bool{
        return $this->successfulyConfigured;
    }

    /**
     * @return int le nombre de tentatives authorisé
     */
    public function getCountOfAuthorizedTry():int{
        return $this->countOfAuthorizedTry;
    }

    /**
     * @return int le nombre de secondes de blocage
     */
    public function getBlockTime():int{
        return $this->blockTime;
    }

    /**
     * @return bool si les données de blocage doivent être rafrachi au succès de la fonction
     */
    public function getResetOnSuccess():bool{
        return $this->resetOnSuccess;
    }   

    /**
     * @return array les moyens de vérifications de réussite
     */
    public function getSuccessTypes():array{
        return $this->successTypes;
    }
}