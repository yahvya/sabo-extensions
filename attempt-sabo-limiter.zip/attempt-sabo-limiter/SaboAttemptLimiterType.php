<?php

namespace SaboExtensions\SaboAttemptLimiter;

/**
 * types de retour de données de la fonction en cas de succès
 */
enum SaboAttemptLimiterType:string{
    /**
     * @return true en cas de succès
     */
    case BOOL = "boolean";
    /**
     * @return null en cas de succès
     */
    case NULL = "null";

    /**
     * @return string en cas de succès
     */
    case STRING = "string";

    /**
     * @return int en cas de succès
     */
    case INT = "integer";

    /**
     * @return float en cas de succès
     */
    case FLOAT = "double";

    /**
     * @return array en cas de succès
     */
    case ARRAY = "array";

    /**
     * @return OBJECT en cas de succès
     */
    case OBJECT = "object";

    /**
     * @return ressource en cas de succès
     */
    case RESSOURCE = "ressource";

    /**
     * si aucun throwable n'est renvoyé alors réussite
     */
    case NO_THROWABLE = "noException";
}