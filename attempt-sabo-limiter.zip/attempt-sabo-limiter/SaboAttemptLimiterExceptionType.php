<?php

namespace SaboExtensions\SaboAttemptLimiter;

/**
 * types d'exception pouvant être envoyé
 */
enum SaboAttemptLimiterExceptionType:string{
    /**
     * erreur en cas de mauvaise configuration de l'attribut
     */
    case BAD_CONFIG = "Veuillez configurer la configuration de la méthode";

    /**
     * erreur en cas de mauvaise appel de la méthode
     */
    case BAD_CALL = "L'appel du gestionnaire est mal formulé veuillez vérifier les conditions nécessaires";

    /**
     * erreur en cas d'appel de la fonction et nombre de tentatives dépassé
     */
    case CURRENTLY_BLOCKED = "Vous avez atteint le nombre de tentatives maximal, veuillez patienter avant de pouvoir reprendre";
}