<?php

namespace SaboExtensions\SaboAttemptLimiter;

use Exception;

class SaboAttemptLimiterException extends Exception{
    /**
     * si l'erreur peut être affiché à l'utilisateur
     */
    private bool $isDisplayable;

    /**
     * @param SaboAttemptLimiterExceptionType $exceptionType le type de l'exception
     * @param bool $isDisplayable si l'eerreur peut être affiché à l'utilisateur
     */
    public function __construct(SaboAttemptLimiterExceptionType $exceptionType,bool $isDisplayable){
        parent::__construct($exceptionType->value);

        $this->isDisplayable = $isDisplayable;
    }

    /**
     * @return bool si l'erreur peut être affiché à l'utilisateur
     */
    public function getIsDisplayable():bool{
        return $this->isDisplayable;
    }
}