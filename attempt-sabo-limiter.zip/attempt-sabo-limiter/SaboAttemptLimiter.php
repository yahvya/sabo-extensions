<?php

namespace SaboExtensions\SaboAttemptLimiter;

use Closure;
use Exception;
use ReflectionFunction;
use ReflectionMethod;
use Sabo\Config\SaboConfig;
use Sabo\Config\SaboConfigAttributes;
use Throwable;
use TypeError;

/**
 * gestionnaire de limitation de tentatives
 * @attention les fonctions fournies doivent être typés pour le bon fonctionnement
 */
class SaboAttemptLimiter{
    /**
     * clé en session
     */
    private const KEY_IN_SESSION = "saboattemptlimiter";

    private array|Closure $toCall;

    /**
     * données du limitable de la méthode
     */
    private SaboAttemptLimitable $limitable;

    /**
     * clé unique lié à la méthode dans la session
     */
    private string $saveKey;

    /**
     * type de retour de la fonction à exécuter
     */
    private string $callableReturnType;

    /**
     * @param array|Closure $toCall callable à gérer
     * @param string|null $uniqId id associé unique dans le programme le même à chaque appel , obligatoire dans le cas d'une closure anonyme
     * @throws Exception en mode debug si la configuration de l'attribut est mauvaise ou manquante
     * @throws SaboAttemptLimiterException si la configuration de l'attribute est mauvaise ou manquante
     */
    public function __construct(array|Closure $toCall,string|null $uniqId = null){
        if(!isset($_SESSION["sabo"][self::KEY_IN_SESSION]) ) $_SESSION["sabo"][self::KEY_IN_SESSION] = [];

        $this->toCall = $toCall;
        
        $this
            ->setLimitable()
            ->setKeyFrom($uniqId);
    }

    /**
     * appelle la fonction du callable et gère le blocage
     * @return mixed la valeur de retour de la fonction ou true par défaut si fonction void
     * @throws SaboAttemptLimiterException si l'utilisateur est bloqué
     * @throws Throwable exception potentielle de la méthode appellé de l'utilosateur
     */
    public function call(mixed ...$args):mixed{
        ["countOfTry" => $countOfTry,"blockTime" => $blockTime] = $this->manageBlockTime()->getLimitationDatas();

        // utilisateur déjà bloqué
        if($blockTime !== null) throw new SaboAttemptLimiterException(SaboAttemptLimiterExceptionType::CURRENTLY_BLOCKED,true);
        
        // on vérifie si l'appel actuel doit bloqué
        if($countOfTry >= $this->limitable->getCountOfAuthorizedTry() ){
            $this->updateBlockTimeDatas($countOfTry,time() );

            throw new SaboAttemptLimiterException(SaboAttemptLimiterExceptionType::CURRENTLY_BLOCKED,true);
        }

        // exécution de la fonction après avoir augmenté le nombre de tentatives d'appel
        $callResult = $this
                ->updateBlockTimeDatas($countOfTry + 1,null)
                ->execCallable($args);
        
        if($this->limitable->getResetOnSuccess() ){
            // vérification de la réussite de la fonction pour rafraichir ou non
            $haveToRefresh = false;
            
            $successVerificationTypes = $this->limitable->getSuccessTypes();

            $callResultType = strtolower(gettype($callResult) );

            // types à ignorer dans la vérification de type
            $toIgnore = [SaboAttemptLimiterType::NO_THROWABLE,SaboAttemptLimiterType::BOOL];

            // vérification des conditions (si un seul des résultat est valide alors ok)
            foreach($successVerificationTypes as $verificationType){
                $isCallable = is_callable($verificationType);

                if(
                    // verification cas callable
                    (
                        $isCallable && 
                        call_user_func_array($verificationType,[$callResult]) === true
                    ) ||
                    // si no_throwable dans les conditons alors vrai par défaut à cette place du code
                    $verificationType === SaboAttemptLimiterType::NO_THROWABLE ||
                    // vérification cas booléen
                    (
                        $verificationType === SaboAttemptLimiterType::BOOL && 
                        $callResult === true
                    ) ||
                    (
                        !$isCallable &&
                        !in_array($verificationType,$toIgnore) &&
                        $callResultType === $verificationType->value
                    )
                ){
                    $haveToRefresh = true;

                    break;
                }
            }
            
            // on peut rafraichir car succès de la fonction
            if($haveToRefresh) $this->updateBlockTimeDatas(0,null);
        }

        return $callResult;
    }

    /**
     * exécute le callable stocké 
     * @return mixed la valeur de retour du callable ou true par défaut si aucun retour du callable
     * @throws Throwable exceptions potentiels de la fonction exécuté
     */
    private function execCallable(array $args):mixed{
        $returnVal = call_user_func_array($this->toCall,$args);

        // retour par défaut true de la fonction si aucun retour au succès
        return $this->callableReturnType === "void" ? true : $returnVal;
    }

    /**
     * met à jour les données de blocage d'accès
     * @param int $withCountOfTry le nombre de tentatives à mettre
     * @param int|null $time le temps à mettre ou null
     * @return SaboAttemptLimiter this
     */
    private function updateBlockTimeDatas(int $withCountOfTry,?int $time):SaboAttemptLimiter{
        // file_put_contents(ROOT . time().".json",json_encode(debug_backtrace(),JSON_PRETTY_PRINT) );
        // sleep(1);
        $_SESSION["sabo"][self::KEY_IN_SESSION][$this->saveKey] = [
            "countOfTry" => $withCountOfTry,
            "blockTime" => $time
        ];


        return $this;
    }

    /**
     * crée les données limitations si elles n'existent pas
     * @return array les données de limitation [countOfTry => int,blockTime => null|int]
     */
    private function getLimitationDatas():array{
        if(empty($_SESSION["sabo"][self::KEY_IN_SESSION][$this->saveKey]) ) $this->updateBlockTimeDatas(0,null);

        return $_SESSION["sabo"][self::KEY_IN_SESSION][$this->saveKey];
    }

    /**
     * récupère une chaine unique et toujours la même lié au callable envoyé
     * @param array|Closure $toCall le callable
     * @param string|null $uniqId id associé unique dans le programme le même à chaque appel , obligatoire dans le cas d'une closure anonyme
     * @return SaboAttemptLimiter this
     * @throws Exception en mode debug si la configuration de l'attribut est mauvaise ou manquante
     * @throws SaboAttemptLimiterException si la configuration de l'attribute est mauvaise ou manquante
     */
    private function setKeyFrom(string|null $uniqId):SaboAttemptLimiter{
        if($uniqId !== null){
            $this->saveKey = $uniqId;

            return $this;
        }

        // si closure et idunique non fourni
        if($this->toCall instanceof Closure){
            if(SaboConfig::getBoolConfig(SaboConfigAttributes::DEBUG_MODE) ) throw new Exception("Un nom unique doit être fournis dans le cas d'un appel par closure");

            throw new SaboAttemptLimiterException(SaboAttemptLimiterExceptionType::BAD_CALL,false);
        }

        // combination du nom pour former la clé
        [$class,$method] = $this->toCall;

        if(strtolower(gettype($class) ) === "object") $class = get_class($class);

        $this->saveKey = "{$class}.{$method}";

        return $this;
    }

    /**
     * effectue les vérifications et affecte limitable / récupère le type de retour de la fonction
     * @throws Exception en mode debug si la configuration de l'attribut est mauvaise ou manquante
     * @throws SaboAttemptLimiterException si la configuration de l'attribute est mauvaise ou manquante
     * @return SaboAttemptLimiter this
     */
    private function setLimitable():SaboAttemptLimiter{
        try{
            // recherche et récupération de l'attribut 
            $reflection = $this->toCall instanceof Closure ? new ReflectionFunction($this->toCall) : new ReflectionMethod(...$this->toCall);

            $limitableAttributes = $reflection->getAttributes(SaboAttemptLimitable::class);
        }
        catch(Exception|TypeError){
            throw new SaboAttemptLimiterException(SaboAttemptLimiterExceptionType::BAD_CONFIG,false);
        }

        // vérification de l'état de configuration de l'attribut
        if(empty($limitableAttributes) ){
            if(SaboConfig::getBoolConfig(SaboConfigAttributes::DEBUG_MODE) ) throw new Exception("L'attribut SaboAttemptLimitable doit être défini sur la fonction {$reflection->getName()}");

            throw new SaboAttemptLimiterException(SaboAttemptLimiterExceptionType::BAD_CONFIG,false);
        }

        $limitableAttribute = $limitableAttributes[0]->newInstance();

        if(!$limitableAttribute->getSuccessfulyConfigured() ) throw new SaboAttemptLimiterException(SaboAttemptLimiterExceptionType::BAD_CONFIG,false);

        $this->callableReturnType = $reflection->getReturnType()->getName();
        $this->limitable = $limitableAttribute;
        
        return $this;
    }

    /**
     * vérifie si le temps de blocage est passé si oui vide les données 
     * @return SaboAttemptLimiter this
     */
    private function manageBlockTime():SaboAttemptLimiter{
        $blockTime = $this->getLimitationDatas()["blockTime"];

        // si le temps de blocage est passé on supprime les données de blocage
        if($blockTime != null && time() - $blockTime >= $this->limitable->getBlockTime() ) unset($_SESSION["sabo"][self::KEY_IN_SESSION][$this->saveKey]);

        return $this;
    }

    /**
     * @param array|Closure $toCall callable à gérer
     * @param string|null $uniqId id associé unique dans le programme le même à chaque appel , obligatoire dans le cas d'une closure anonyme
     * @throws Exception en mode debug si la configuration de l'attribut est mauvaise ou manquante
     * @throws SaboAttemptLimiterException si la configuration de l'attribute est mauvaise ou manquante
     */
    public static function from(array|Closure $toCall,string|null $uniqId = null):SaboAttemptLimiter{
        return new SaboAttemptLimiter($toCall,$uniqId);
    }
}