<?php

namespace SaboExtensions\Eshop\Payment\Receipt;

use Exception;
use Sabo\Config\SaboConfig;
use Sabo\Config\SaboConfigAttributes;
use Sabo\Controller\Controller\SaboController;
use SaboExtensions\Eshop\Payment\Payment\SaboPayment;
use Spipu\Html2Pdf\Html2Pdf;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

/**
 *  créateur de reçu par défaut de sabo
 */
class SaboDefaultReceiptCreator implements SaboReceiptCreator{
    public function createReceipt(SaboPayment $payment,string $dstPath):bool{
        try{
            $pdfCreator = new Html2Pdf();

            $loader = new FilesystemLoader(__DIR__ . "\\..\\storage");

            $twig = new Environment($loader,[
                "debug" => SaboConfig::getBoolConfig(SaboConfigAttributes::DEBUG_MODE)
            ]);

            // ajout des extension
            foreach(SaboController::$twigExtensions as $twigExtension) $twig->addExtension($twigExtension);

            $viewData = [
                "payer" => $payment->getPayer(),
                "payables" => $payment->getPayables(),
                "priceFormatter" => $payment->getPriceFormatter(),
                "payment" => $payment
            ];

            $pdfCreator->writeHTML($twig->render("receipt-template.twig",$viewData) );

            $directory = dirname($dstPath);

            if(!is_dir($directory) ) mkdir($directory,recursive: true);

            $pdfCreator->output($dstPath,"F");

            return true;
        }
        catch(Exception $e){}

        return false;
    }
}