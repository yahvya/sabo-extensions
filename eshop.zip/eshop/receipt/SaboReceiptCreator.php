<?php

namespace SaboExtensions\Eshop\Payment\Receipt;

use SaboExtensions\Eshop\Payment\Payment\SaboPayment;

/**
 * représente un créateur de reçu
 */
interface SaboReceiptCreator{
    /**
     * crée le reçu 
     * @param SaboPayment $payment l'instance de paiement à transformer
     * @param string $dstPath le chemin de destination du fichier généré
     * @return bool si le reçu a bien été généré
     */
    public function createReceipt(SaboPayment $payment,string $dstPath):bool;
}