<?php

namespace SaboExtensions\Eshop\Payable;

/**
 * formatteur l'élement à payer pour la transformation sous forme de chaine
 */
interface SaboPayableToString{
    /**
     * @param SaboPayable $payable le payable
     * @return string formatte l'élement à payer sous forme de chaine
     */
    public function toString(SaboPayable $payable):string;
}