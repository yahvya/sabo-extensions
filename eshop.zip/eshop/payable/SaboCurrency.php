<?php

namespace SaboExtensions\Eshop\Payable;

/**
 * représentation du moyen de paiement
 */
class SaboCurrency{
    protected string $appCurrency;

    protected null|string|int $paymentMethodCurrency;

    protected SaboCurrencyType $currencyType;

    public function __construct(string $appCurrency,SaboCurrencyType $currencyType,int|string|null $paymentMethodCurrency = null){
        $this->appCurrency = $appCurrency;
        $this->currencyType = $currencyType;

        switch($currencyType){
            case SaboCurrencyType::SAME_AS_APP:
                $this->paymentMethodCurrency = $this->appCurrency;
            ; break;

            default:
                $this->paymentMethodCurrency = $paymentMethodCurrency;
            ;
        }
    }   

    /**
     * @return string le moyen interne à l'application
     */
    public function getAppCurrency():string{
        return $this->appCurrency;
    }   

    /**
     * @return SaboCurrencyType le type de moyen
     */
    public function getCurrencyType():SaboCurrencyType{
        return $this->currencyType;
    }

    /**
     * @return null|string|int le moyen pour le moyen de paiement
     */
    public function getPaymentMethodCurrency():null|string|int{
        return $this->paymentMethodCurrency;
    }
}