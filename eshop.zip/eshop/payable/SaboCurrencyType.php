<?php

namespace SaboExtensions\Eshop\Payable;

/**
 * type de représentation
 */
enum SaboCurrencyType{
    /**
     * sous forme de chaine - utilise la même valeur que celle interna à l'application
     */
    case SAME_AS_APP;

    /**
     * sous forme de chaine
     */
    case STR_CURRENCY;

    /**
     * sous forme de nombre
     */
    case DIGITAL_CURRENCY;
}