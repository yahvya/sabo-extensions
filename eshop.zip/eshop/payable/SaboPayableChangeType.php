<?php

namespace SaboExtensions\Eshop\Payable;

enum SaboPayableChangeType:int{
    /**
     * changement du nom de l'élement 
     */
    case ELEMENT_NAME_CHANGE = 1;

    /**
     * changement de la description
     */
    case ELEMENT_DESCRIPTION_CHANGE = 2;

    /**
     * changement du prix
     */
    case ELEMENT_PRICE_CHANGE = 3;

    /**
     * changement de quantité
     */
    case ELEMENT_QUANTITY_CHANGE = 4;

    /**
     * changement de l'id interne
     */
    case ELEMENT_INTERNAL_ID_CHANGE = 5;
}