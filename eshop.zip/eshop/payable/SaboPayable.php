<?php

namespace SaboExtensions\Eshop\Payable;

use SaboExtensions\Eshop\Cart\SaboCart;
use SaboExtensions\Eshop\Payment\Util\SaboPaymentChangeable;

/**
 * élement à payer
 */
class SaboPayable extends SaboPaymentChangeable{
    /**
     * nom de l'élement à payer
     */
    protected ?string $elementName;

    /**
     * description de l'élement à payer
     */
    protected ?string $description;
        
    /**
     * prix de l'élement à payer
     */
    protected float $price; 

    /**
     * quantité de l'élement
     */
    protected int $quantity;

    /**
     * le moyen utilisé
     */
    protected SaboCurrency $currency; 

    /**
     * id lié à l'interne à l'élement
     */
    protected ?int $internalId;

    /**
     * liste des id attribués dans les paniers
     */
    protected array $idInCarts;

    /**
     * données supplémentaires sur l'article
     */
    protected array $payableSupplementaryDatas;

    /**
     * @param float $price le prix à payer
     * @param int $quantity nombre d'élements
     * @param string|null $elementName nom de l'élement à payer
     * @param string|null $description description de l'élement à payer
     * @param int|null $internalId id interne
     * @param array $payableSupplementaryDatas données supplémentaires 
     * @attention les données supplémentaires doivent être serializable
     */
    public function __construct(float $price,int $quantity,SaboCurrency $currency,?string $elementName = null,?string $description = null,?int $internalId = null,array $payableSupplementaryDatas = []){
        // attribution de l'id changeable
        parent::__construct();

        $this->price = $price;
        $this->quantity = $quantity;
        $this->elementName = $elementName;
        $this->description = $description;
        $this->currency = $currency;
        $this->internalId = $internalId;
        $this->payableSupplementaryDatas = $payableSupplementaryDatas;
        $this->idInCarts = [];
    }

    /**
     * met à jour la valeur
     * @param string|null $elementName nom de l'élement
     * @return SaboPayable this
     */
    public function setElementName(?string $elementName):SaboPayable{
        $previousValue = $this->elementName;

        $this->elementName = $elementName;

        $this->propagateChange(SaboPayableChangeType::ELEMENT_NAME_CHANGE->value,$previousValue);
        
        return $this;
    }

    /**
     * met à jour la valeur
     * @param string|null $description description de l'élement
     * @return SaboPayable his
     */
    public function setDescription(?string $description):SaboPayable{
        $previousValue = $this->description;

        $this->description = $description;

        $this->propagateChange(SaboPayableChangeType::ELEMENT_DESCRIPTION_CHANGE->value,$previousValue);
        
        return $this;
    }


    /**
     * met à jour la valeur
     * @param float price prix de l'élement
     * @return SaboPayable this
     */
    public function setPrice(float $price):SaboPayable{
        $previousValue = $this->price;

        $this->price = $price;

        $this->propagateChange(SaboPayableChangeType::ELEMENT_PRICE_CHANGE->value,$previousValue);

        return $this;
    }

    /**
     * met à jour la valeur
     * @param int $quantity quantité de l'élement
     * @return SaboPayable this
     */
    public function setQuantity(int $quantity):SaboPayable{
        $previousValue = $this->quantity;

        $this->quantity = $quantity;

        $this->propagateChange(SaboPayableChangeType::ELEMENT_QUANTITY_CHANGE->value,$previousValue);

        return $this;
    }

    /**
     * lie l'id au panier 
     * @param SaboCart $cart le panier
     * @param int $id l'id lié
     * @return SaboPayable this
     */
    public function setIdInCart(SaboCart $cart,int $id):SaboPayable{
        $this->idInCarts[$cart->getListenerAttributedId()] = $id;

        return $this;
    }

    /**
     * @param SaboCart $cart
     * @return  int|null l'id lié ou null si non trouvé
     */
    public function getIdInCart(SaboCart $cart):?int{
        $key = $cart->getListenerAttributedId();

        return array_key_exists($key,$this->idInCarts) ? $this->idInCarts[$key] : null;
    }

    /**
     * retire l'id lié
     * @return SaboPayable this
     */
    public function removeIdInCart(SaboCart $cart):SaboPayable{
        $key = $cart->getListenerAttributedId();

        if(array_key_exists($key,$this->idInCarts) ) unset($this->idInCarts[$key]);

        return $this;
    }

    /**
     * @return string|null le nom de l'élement à payer ou null si aucun nom donné
     */
    public function getElementName():?string{
        return $this->elementName;
    }

    /**
     * @return string|null la description de l'élélent à payer ou null si aucune description donné
     */
    public function getDescription():?string{
        return $this->description;
    }

    /**
     * lie une id à l'élément
     * @param int|null $internalId l'id associé à l'élement dans le programme utilisateur
     * @return SaboPayable this
     */
    public function setInternalId(?int $internalId):SaboPayable{
        $previousValue = $this->internalId;

        $this->internalId = $internalId;

        $this->propagateChange(SaboPayableChangeType::ELEMENT_INTERNAL_ID_CHANGE->value,$previousValue);

        return $this;
    }

    /**
     * @return int|null l'id interne lié
     */
    public function getInternalId():?int{
        return $this->internalId;
    }

    /**
     * @return float le prix d'un seul élement
     */
    public function getSinglePrice():float{
        return $this->price;
    }

    /**
     * @return float le prix d'un seul élement
     */
    public function getSingleFormattedPrice(SaboEshopPriceFormatter $formatter):float{
        return $formatter->getFormattedPriceFrom($this->price);
    }

    /**
     * @return float le prix de l'élément à payer par rapport à la quantité
     */
    public function getPrice():float{
        return $this->price * $this->quantity;
    }

    /**
     * @param SaboEshopPriceFormatter $formatter le formatteur de prix
     * @return float le prix formatté de l'élément à payer par rapport à la quantité
     */
    public function getFormattedPrice(SaboEshopPriceFormatter $formatter):float{
        return $formatter->getFormattedPriceFrom($this->price * $this->quantity);
    }

    /**
     * @return int le nombre d'élements
     */
    public function getQuantity():int{
        return $this->quantity;
    }

    /**
     * @return string l'article sous forme de chaine
     */
    public function toString(?SaboPayableToString $stringFormatter = null):string{
        if($stringFormatter == null)
            return "{$this->elementName} x{$this->quantity} {$this->price} ({$this->currency->getAppCurrency()})";
        else 
            return $stringFormatter->toString($this);
    }

    /**
     * met à jour les données supplémentaires de l'élement écrase les clés existante et ajoute les nouvelles clés 
     * @attention les valeurs des clés existantes qui n'apparaissent pas dans newDatas sont conservé (modification au niveau 1 des clés)
     * @param array $newDatas nouvelles données 
     * @attention les données supplémentaires doivent être serializable
     * @return SaboPayable this
     */
    public function updatePayableSupplementaryDatas(array $newDatas):SaboPayable{
        foreach($newDatas as $key => $data) $this->payableSupplementaryDatas[$key] = $data;

        return $this;
    }

    /**
     * @return SaboCurrency le moyen lié à l'attribut
     */
    public function getCurrency():SaboCurrency{
        return $this->currency;
    }

    /**
     * @return array les données supplémentaires de l'élément
     */
    public function getPayableSupplementaryDatas():array{
        return $this->payableSupplementaryDatas;
    }

    /**
     * calcule le prix total des articles par leur quantité
     * @param SaboPayable ...$payables paramètres multiples , les payables
     * @return float le prix calculé
     */
    public static function getToTalPrice(SaboPayable... $payables):float{
        $price = 0;

        foreach($payables as $payable) $price += $payable->price * $payable->quantity;

        return $price;
    }
}