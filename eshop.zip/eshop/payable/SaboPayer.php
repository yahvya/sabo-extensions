<?php

namespace SaboExtensions\Eshop\Payable;

/**
 * payeur
 */
class SaboPayer{
    /**
     * nom
     */
    protected string $payerName;
    
    /**
     * prénom
     */
    protected string $payerFname;

    /**
     * numéro de téléphone
     */
    protected ?string $payerPhonenumber;

    /**
     * email du payeur
     */
    protected ?string $email;

    /**
     * défini si le payeur à une adresse
     */
    protected bool $haveAddress;

    /**
     * adresse inf 1
     */
    protected string $address;

    /**
     * complément adresse
     */
    protected ?string $adressComplement;

    /**
     * code postal
     */
    protected string $postalCode;

    /**
     * pays
     */
    protected string $country;

    /**
     * ville
     */
    protected string $city;

    /**
     * @param string $payerName nom du payeur
     * @param string $payerFname prénom du payeur
     * @param string|null $payerPhonenumber numéro du payeur ou null si non connu
     * @param string|null $payerEmail email du payeur
     */
    public function __construct(string $payerName,string $payerFname,?string $payerPhonenumber = null,?string $payerEmail = null){
        $this->payerName = $payerName;
        $this->payerFname = $payerFname;
        $this->payerPhonenumber = $payerPhonenumber;
        $this->email = $payerEmail;
        $this->haveAddress = false;
    }

    /**
     * défini l'adresse
     * @param string $address adresse
     * @param string $postalCode code postal
     * @param string $city ville
     * @param string $country pays
     * @param string|null $adressComplement complément d'adresse
     */
    public function setAddress(string $address,string $postalCode,string $city,string $country,?string $addressComplement = null):SaboPayer{
        $this->haveAddress = true;
        $this->address = $address;
        $this->postalCode = $postalCode;
        $this->city = $city;
        $this->country = $country;
        $this->adressComplement = $addressComplement;

        return $this;
    }

    /**
     * @return bool si le payeur une adresse est renseigné
     */
    public function getHaveAddress():bool{
        return $this->haveAddress;
    }

    /**
     * @return string l'adresse complète
     */
    public function getCompleteAddress():?string{
        return !$this->haveAddress ? null : "{$this->address} " . ($this->adressComplement ?? "") . " {$this->city} {$this->country},{$this->postalCode}"; 
    }

    /**
     * @return string nom
     */
    public function getPayerName():string{
        return $this->payerName;
    }

    /**
     * @return string prénom
     */
    public function getPayerFname():string{
        return $this->payerFname;
    }

    /**
     * @return string numéro de téléphone
     */
    public function getPayerPhonenumber():?string{
        return $this->payerPhonenumber;
    }

    /**
     * @return string l'adresse
     */
    public function getAddress():string{
        return $this->address;
    }

    /**
     * @return string|null le complément d'adresse ou null si aucun renseigné
     */
    public function getAddressComplement():?string{
        return $this->adressComplement;
    }

    /**
     * @return string le code postal
     */
    public function getPostalCode():string{
        return $this->postalCode;
    }

    /**
     * @return string le pays
     */
    public function getCountry():string{
        return $this->country;
    }

    /**
     * @return string la ville
     */
    public function getCity():string{
        return $this->city;
    }

    /**
     * @return string email
     */
    public function getEmail():?string{
        return $this->email;
    }
}