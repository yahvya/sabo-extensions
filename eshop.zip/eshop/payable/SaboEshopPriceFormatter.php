<?php

namespace SaboExtensions\Eshop\Payable;

/**
 * formatteur de prix pour le moyen de paiement utilisé
 */
interface SaboEshopPriceFormatter{
    /**
     * @param float $price le prix de l'élement à payer
     * @return float le prix formatté
     */
    public function getFormattedPriceFrom(float $price):float; 
}