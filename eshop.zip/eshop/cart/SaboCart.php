<?php

namespace SaboExtensions\Eshop\Cart;

use DateTime;
use SaboExtensions\Eshop\Payable\SaboPayable;
use SaboExtensions\Eshop\Payable\SaboPayableChangeType;
use SaboExtensions\Eshop\Payable\SaboPayer;
use SaboExtensions\Eshop\Payment\Util\SaboPaymentChangeType;
use SaboExtensions\Eshop\Payment\Util\SaboPaymentListener;

/**
 * panier d'élements
 * les modifications faîtes en dehors du panier sur un objet sont accepté
 * par défaut toute action permet la mise à jour du dernier évenement fait
 */
 class SaboCart extends SaboPaymentListener{
    /**
     * élements du panier
     */
    protected array $cartPayables;

    /**
     * le nombre d'élements dans le panier
     */
    protected int $countOfPayables;

    /**
     * le nombre d'élements dans le panier en y comptant la quantité de chaque élements
     */
    protected int $countOfPayablesQuantity;

    /**
     * payeur du panier
     */
    protected ?SaboPayer $payer;

    /**
     * moment de création du panier
     */
    protected DateTime $creationTime;

    /**
     * actions permettant la mise à jour du moment de la dernière action faîtes
     */
    protected array $actionsMatter;

    /**
     * données supplémentaires liés au panier
     */
    protected array $cartSupplementaryDatas;

    /**
     * id des payables dans le panier
     */
    protected int $idInCart;

    /**
     * moment de la dernière action faîtes
     */
    protected int $lastActionTime;

    /**
     * @param SaboPayer|null $payer payeur modifiable
     * @param array $elements liste des élements à payer (SaboPayable)
     * @param array $cartSupplementaryDatas données supplémentaires lié au panier (doivent être serializable)
     */
    public function __construct(?SaboPayer $payer = null,array $cartPayables = [],array $cartSupplementaryDatas = []){
        parent::__construct();

        $this->payer = $payer;
        $this->cartPayables = $cartPayables;
        $this->creationTime = new DateTime();
        $this->lastActionTime = time();
        $this->actionsMatter = [];
        $this->countOfPayables = count($cartPayables);
        $this->countOfPayablesQuantity = 0;
        $this->idInCart = 1;
        $this->cartSupplementaryDatas = $cartSupplementaryDatas;

        foreach(SaboCartActionsMatter::cases() as $case) $this->actionsMatter[$case->value] = true;

        foreach($cartPayables as $cartElement){
            $this->countOfPayablesQuantity += $cartElement->getQuantity();

            $cartElement
                ->setIdInCart($this,$this->idInCart)
                ->addListener($this);

            $this->idInCart++;
        }
    }

    public function changeHappen(SaboPaymentChangeType $changeType,mixed $previousValue,mixed $on):SaboCart{

        // mise à jour de la quantité totale
        if($changeType->matchChange(SaboPayableChangeType::ELEMENT_QUANTITY_CHANGE->value) ){
            $this->countOfPayablesQuantity -= $previousValue;
            $this->countOfPayablesQuantity += $on->getQuantity();
            $this->updateLastActionMomentFrom(SaboCartActionsMatter::PAYABLE_QUANTITY_CHANGE);
        }

        return $this;
    }

    /**
     * ajoute des élements au panier
     * @attention aux ajouts de payables double quantités pouvant être dérangé
     * @param SaboPayable ...$payables multiples SaboPayable
     * @return SaboCart this
     */
    public function addPayables(SaboPayable... $payables):SaboCart{
        $toAdd = [];

        foreach($payables as $payable){
            if($payable->getIdInCart($this) != null) continue;

            array_push($toAdd,$payable);

            $this->countOfPayables++;
            $this->countOfPayablesQuantity += $payable->getQuantity();
            
            $payable
                ->setIdInCart($this,$this->idInCart)
                ->addListener($this);

            $this->idInCart++;
        }

        $this->cartPayables = array_merge($this->cartPayables,$toAdd);

        $this->updateLastActionMomentFrom(SaboCartActionsMatter::ADD_PAYABLE);

        return $this;
    }

    /**
     * supprime des éléments du panier qui sont lié aux id envoyé
     * @param int ...$linkedIds multiples , id lié aux éléments
     * @return SaboPayable this
     */
    public function removePayables(int... $linkedIds):SaboCart{
        foreach($this->cartPayables as $key => $payable){
            if(in_array($payable->getInternalId(),$linkedIds) ){
                unset($this->cartPayables[$key]);

                $this->countOfPayables--;
                $this->countOfPayablesQuantity -= $payable->getQuantity();

                $payable
                    ->removeIdInCart($this)
                    ->stopBeingListened($this);
            }
        }

        $this->cartPayables = array_values($this->cartPayables);

        $this->updateLastActionMomentFrom(SaboCartActionsMatter::REMOVE_PAYABLE);

        return $this;
    }

    /**
     * récupère des éléments du panier qui sont lié aux id envoyé
     * @param int ...$linkedIds multiples , id lié aux éléments
     * @return array les élements trouvés
     */
    public function getPayablesFrom(int... $linkedIds):array{
        $result = [];

        foreach($this->cartPayables as $payable){
            if(in_array($payable->getInternalId(),$linkedIds) )
                array_push($result,$payable);
        }

        return $result;
    }

    /**
     * @return array tous les élements du panier
     */
    public function getPayables():array{
        return $this->cartPayables;
    }

    /**
     * vide les élements du panier
     * @return SaboCart this
     */
    public function clear():SaboCart{
        // libération des liens
        foreach($this->cartPayables as $payable){
            $payable
                ->removeIdInCart($this)
                ->stopBeingListened($this);   
        }

        $this->countOfPayables = 0;
        $this->countOfPayablesQuantity = 0;
        $this->cartPayables = [];

        $this->updateLastActionMomentFrom(SaboCartActionsMatter::CLEAR_CART);

        return $this;
    }

    /**
     * @return int le nombre d'élements dans le panier
     */
    public function getCountOfPayables():int{
        return $this->countOfPayables;
    }   

    /**
     * @return int le nombre d'élements dans le panier en y comptant la quantité de chaque élements
     */
    public function getCountOfPayablesWQuantity():int{
        return $this->countOfPayablesQuantity;
    }

    /**
     * sauvegarde ce panier dans le session
     * @param string $key la clé de session (niveau1.niveau2.niveau3)
     * @return SaboCart this
     */
    public function storeCartInSession(string $key):SaboCart{
        self::storeRec($_SESSION,$key,$this->serialize() );

        $this->updateLastActionMomentFrom(SaboCartActionsMatter::STORE_IN_SESSION);

        return $this;
    }

    /**
     * serialize le panier
     * @return string|null la version serialize ou null en cas d'échec
     */
    public function serialize():string{
        return serialize($this);
    }

    /**
     * met à jour le payeur
     * @param SaboPayer|null $payer le payeur
     */
    public function setPayer(?SaboPayer $payer):SaboCart{
        $this->payer = $payer;

        $this->updateLastActionMomentFrom(SaboCartActionsMatter::PAYER_UPDATE);

        return $this;
    }

    /**
     * met à jour les données supplémentaires du panier écrase les clés existante et ajoute les nouvelles clés 
     * @attention les valeurs des clés existantes qui n'apparaissent pas dans newDatas sont conservé (modification au niveau 1 des clés)
     * @param array $newDatas nouvelles données
     * @return SaboCart this
     */
    public function updateCartSupplementaryDatas(array $newDatas):SaboCart{
        foreach($newDatas as $key => $data) $this->cartSupplementaryDatas[$key] = $data;

        return $this;
    }

    /**
     * @return SaboPayer|null le payeur lié ou null
     */
    public function getPayer():?SaboPayer{
        return $this->payer;
    }   

    /**
     * @return DateTime le moment de création du panier
     */
    public function getCreationTime():DateTime{
        return $this->creationTime;
    }

    /**
     * @return DateTime le moment de la dernière action faîtes
     */
    public function getLastActionTime():DateTime{
        return (new DateTime)->setTimestamp($this->lastActionTime);
    }

    /**
     * @return array les données supplémentaires du panier
     */
    public function getCartSupplementaryDatas():array{
        return $this->cartSupplementaryDatas;
    }

    /**
     * ajoute une action permettant la mise à jour de la dernière action faîtes
     * @return SaboCart this
     */
    public function addActionMatter(SaboCartActionsMatter $action):SaboCart{
        $this->actionsMatter[$action->value] = true;
        
        return $this;
    }

    /**
     * retire une action permettant la mise à jour de la dernière action faîtes
     * @return SaboCart this
     */
    public function removeActionMatter(SaboCartActionsMatter $action):SaboCart{
        $this->actionsMatter[$action->value] = false;
        
        return $this;
    }

    /**
     * vérifie si le panier à expiré
     * @param int $expirationDelay délai autorisé du panier en secondes
     * @return bool si le panier à expiré en fonction de la date de la dernière action faîtes
     */
    public function isExpired(int $expirationDelay):bool{
        return SaboCartExpirationManager::isExpired($this,$expirationDelay);
    }

    /**
     * met à jour le temps de la dernière action faîtes si possible
     * @pâram action l'action faîtes
     * @return SaboCart this
     */
    protected function updateLastActionMomentFrom(SaboCartActionsMatter $action):SaboCart{
        if($this->actionsMatter[$action->value]) $this->lastActionTime = time();

        return $this;
    }

    /**
     * récupère et crée le panier à partir de la session
     * @param string $key la clé de session (niveau1.niveau2.niveau3)
     * @return SaboCart|null la panier ou null si non trouvé ou erreur
     */
    public static function getCartFromSession(string $key):?SaboCart{
        $foundedValue = self::getRec($_SESSION,$key);

        if($foundedValue == null) return null;

        $class = @unserialize($foundedValue);

        if($class == false || !$class instanceof SaboCart) return null;

        $class->updateLastActionMomentFrom(SaboCartActionsMatter::GET_FROM_SESSION);

        return $class;
    }

    /**
     * sauvegarde un élement dans un tableau sous plusieurs niveaux
     * @param array le tableau dans lequel stocker
     * @param string $key clé au format niveau1.niveau2.niveau3
     * @param mixed $data la donnée à stocker
     */
    protected static function storeRec(array &$array,string $key,mixed $data):void{
        $parts = explode(".",$key); 

        $key = array_shift($parts);

        if(!array_key_exists($key,$array) ) $array[$key] = [];

        if(count($parts) == 0)
            $array[$key] = $data;
        else
            self::storeRec($array[$key],implode(".",$parts),$data);
    }

    /**
     * récupère un élement dans un tableay sous plusieurs niveaux
     * @param array le tableau 
     * @param string $key clé au format niveau1.niveau2.niveau3
     * @return mixed la donné ou null si non trouvé
     */
    protected static function getRec(array $array,string $key):mixed{
        $parts = explode(".",$key);

        foreach($parts as $part){
            if(gettype($array) != "array" || !array_key_exists($part,$array) ) return null;
            
            $array = $array[$part];
        }

        return $array;
    }
 }
