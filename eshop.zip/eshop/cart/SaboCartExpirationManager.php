<?php

namespace SaboExtensions\Eshop\Cart;

use DateTime;

/**
 * gesitonnaire d'expiration
 */
abstract class SaboCartExpirationManager{
    /**
     * vérifie si le panier à expiré
     * @param SaboCart $cart le panier
     * @param int $expirationDelay délai autorisé du panier en secondes
     * @return bool si le panier à expiré en fonction de la date de la dernière action faîtes
     */
    public static function isExpired(SaboCart $cart,int $expirationDelay):bool{
        $diffInSeconds = (new DateTime)->getTimestamp() - $cart->getLastActionTime()->getTimestamp();

        return !($diffInSeconds < $expirationDelay);
    }
}