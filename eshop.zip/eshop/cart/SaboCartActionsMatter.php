<?php

namespace SaboExtensions\Eshop\Cart;

/**
 * actions pouvant mettre à jour le temps de la dernière action faites sur le panier
 */
enum SaboCartActionsMatter:int{ 
    /**
     * l'ajout de payable
     */
    case ADD_PAYABLE = 1;

    /**
     * la suppression de payable
     */
    case REMOVE_PAYABLE = 2;

    /**
     * la modification de quantité d'un des payables
     */
    case PAYABLE_QUANTITY_CHANGE = 3;

    /**
     * vidage du panier
     */
    case CLEAR_CART = 4;

    /**
     * stockage du panier en session
     */
    case STORE_IN_SESSION = 5;

    /**
     * récupération du panier en session
     */
    case GET_FROM_SESSION = 6;

    /**
     * mise à jour du payeur
     */
    case PAYER_UPDATE = 7;
}