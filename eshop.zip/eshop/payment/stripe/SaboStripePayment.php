<?php

namespace SaboExtensions\Eshop\Payment\Stripe;

use Closure;
use Sabo\Controller\Controller\SaboController;
use Sabo\Utils\Api\SaboApiRequest;
use SaboExtensions\Eshop\Cart\SaboCart;
use SaboExtensions\Eshop\Payable\SaboPayable;
use SaboExtensions\Eshop\Payable\SaboPayer;
use SaboExtensions\Eshop\Payment\Payment\SaboPayment;
use SaboExtensions\Eshop\Payment\Payment\SaboPaymentState;
use SaboExtensions\Eshop\Payment\Payment\SaboWebhookPayment;
use SaboExtensions\Eshop\Payment\Util\SaboPaymentAction;
use SaboExtensions\Eshop\Payment\Util\SaboPaymentApiCaller;
use SaboExtensions\Eshop\Payment\Util\SaboToGet;

/**
 * paiement par carte bancaire classique
 * @attention les élements doivent avoir la même valeur de currency
 * @version 2022-08-01
 */
class SaboStripePayment extends SaboWebhookPayment{
    /**
     * monnaie par défaut
     */
    protected const DEFAULT_CURRENCY = "eur";

    /**
     * version de l'api
     */
    protected const API_VERSION = "2022-08-01";

    /**
     * clé secrète stripe
     */
    protected string $secretKey;
    /**
     * clé publique stripe
     */
    protected string $publicKey;
    /**
     * clé scrète des webhook stripe
     */
    protected string $endpointSecret;
    /**
     * url de retour en cas de paiement fait
     */
    protected string $successUrl;
    /**
     * url de retour en cas d'annulation de paiement
     */
    protected string $cancelUrl;

    public function __construct(SaboPayer $linkedPayer,array $payables,string $successUrl,string $cancelUrl){
        parent::__construct($linkedPayer,$payables);

        $this->successUrl = $successUrl;
        $this->cancelUrl = $cancelUrl;
        $this->priceFormatter = new SaboStripePriceFormatter();
    }

    public function configure():bool{
        // récupération des données apis
        $configDatas = self::getConfiguration();

        if($configDatas == null) return false;

        list(
            "publicKey" => $this->publicKey,
            "secretKey" => $this->secretKey,
            "endpointSecret" => $this->endpointSecret
        ) = $configDatas;

        $this->apiCaller = new SaboPaymentApiCaller($configDatas["url"]);
        $this->paymentState = SaboPaymentState::INITIALIZED;

        return true;
    }

    /**
     * fais le paiement 
     * état du paiment mis à jour vers ABOUT_TO_PAY
     * @param array $customOptions options customisés
     * @param string|null $shippingDisplayName texte à afficher en cas de livraison payante ou null
     * @param Closure|null $toExecBefore closure booléenne à exécuter avant la redirection de paiement
     * @return bool false si une erreur se produit
     */
    public function madePayment(array $customOptions = [],?string $shippingDisplayName = null,?Closure $toExecBefore = null):bool{
        $totalPrice = 0;

        $order = $this->createOrder($totalPrice);

        $currency = !empty($this->payables) ? strtolower($this->payables[0]->getCurrency()->getPaymentMethodCurrency() ) : self::DEFAULT_CURRENCY;

        // corps checkout stripe
        $data = [
            "success_url" => $this->successUrl,
            "cancel_url" => $this->cancelUrl,
            "line_items" => $order,
            "mode" => "payment",
            "currency" => $currency,
            "submit_type" => "pay",
            "payment_method_types" => ["card"]
        ];

        $deliveryPrice = 0;

        // ajout de la livraison
        if($this->includeDelivery){
            $deliveryPrice = $this->priceFormatter->getFormattedPriceFrom(self::applyDiscountOn($this->deliveryPrice,$this->deliveryDiscountPercent) );

            $data["shipping_options"] = [
                [
                    "shipping_rate_data" => [
                        "display_name" => $shippingDisplayName,
                        "type" => "fixed_amount",
                        "fixed_amount" => [
                            "amount" => $deliveryPrice,
                            "currency" => $currency
                        ]
                    ]
                ]
            ];
        }

        $payedPrice = $totalPrice + $deliveryPrice;

        // ajout de la promotion
        if($this->elementsToPayDiscountPercent != 0){
            $payedPrice -= self::applyDiscountOn($totalPrice,$this->elementsToPayDiscountPercent);

            $discountData = $this->createDiscountFrom($this->elementsToPayDiscountPercent,$currency);

            if($discountData == null) return false;

            $data["discounts"] = [$discountData];
        }

        $payerEmail = $this->payer->getEmail();

        if($payerEmail != null) $data["customer_email"] = $payerEmail;

        $data = array_merge_recursive($data,$customOptions);

        $callSuccess = $this->apiCaller->request(
            $this->apiCaller->apiUrl("v1/checkout/sessions"),
            $this->headers(),
            $data,
            SaboApiRequest::HTTP_BUILD_QUERY
        );

        if(!$callSuccess) return false;

        $paymentData = $this->apiCaller->getLastRequestResult(SaboApiRequest::RESULT_AS_JSON_ARRAY) ?? [];

        if(!self::containKeys($paymentData,"url") ) return false;

        $this->paymentState = SaboPaymentState::ABOUT_TO_PAY;
        $this->finalPaymentData = [
            "elementsToPayPrice" => $totalPrice,
            "deliveryPrice" => $deliveryPrice,
            "payedPrice" => $payedPrice
        ];
        
        if($toExecBefore != null && !$toExecBefore() ) return false;

        SaboController::redirectToLink($paymentData["url"]);

        return false;
    }

    /**
     * crée une promotion à durée 1
     * @param float $discountPercent pourcentage de réduction
     * @param string $currency monnaie
     * @return array les données de la promotion ou null en cas d'erreur
     */
    protected function createDiscountFrom(float $discountPercent,string $currency):?array{
        $data = [
            "percent_off" => $discountPercent,
            "currency" => $currency,
            "duration" => "once"
        ];

        $callSuccess = $this->apiCaller->request(
            $this->apiCaller->apiUrl("v1/coupons"),
            $this->headers(),
            $data,
            SaboApiRequest::HTTP_BUILD_QUERY
        );

        if(!$callSuccess) return null;

        $data = $this->apiCaller->getLastRequestResult(SaboApiRequest::RESULT_AS_JSON_ARRAY) ?? [];

        if(!self::containKeys($data,"id") ) return null;
        
        return [
            "coupon" => $data["id"] 
        ];
    }

    /**
     * crée les payables au format stripe
     * @param float $totalPrice prix total des élements
     * @return array la liste des payables crées
     */
    protected function createOrder(float &$totalPrice):array{
        $totalPrice = 0;

        $order = array_map(function(SaboPayable $payable)use(&$totalPrice):array{
            $totalPrice += $payable->getFormattedPrice($this->priceFormatter);
            
            return [
                "price_data" => [
                    "currency" => strtolower($payable->getCurrency()->getPaymentMethodCurrency() ?? self::DEFAULT_CURRENCY),
                    "unit_amount" => $payable->getSingleFormattedPrice($this->priceFormatter),
                    "product_data" => [
                        "name" => $payable->getElementName() ?? "Produit"
                    ]
                ],
                "quantity" => $payable->getQuantity()
            ];
        },$this->payables);

        $totalPrice = $this->priceFormatter->getFormattedPriceFrom($totalPrice);

        return $order;
    }

    /**
     * met à jour l'url cancel
     * @param string $cancelUrl l'url cancel
     * @return SaboStripePayment this
     */
    public function setCancelUrl(string $cancelUrl):SaboStripePayment{
        $this->cancelUrl = $cancelUrl;
        
        return $this;
    }

    /**
     * met à jour l'url cancel
     * @param string $successUrl l'url success
     * @return SaboStripePayment this
     */
    public function setSuccessUrl(string $successUrl):SaboStripePayment{
        $this->successUrl = $successUrl;
        
        return $this;
    }

    /**
     * ajoute les en-têtes stripe 
     * @param array $headers en-têtes
     * @return array les en-têtes merge
     */
    protected function headers(array $headers = []):array{
        array_push($headers,"Authorization: Bearer {$this->secretKey}","Stripe-Version: " . self::API_VERSION);
        
        return $headers;
    }

    /**
     * @indice publicKey
     * @indice secretKey
     * @indice endpointSecret
     * @indice url
     */
    public static function getConfiguration():?array{
        return self::getDataFromConfig(
            new SaboToGet(SaboStripeConfig::JSON_URL->value,SaboStripeConfig::CLASSIC_ENV_URL->value,"url"),
            new SaboToGet(SaboStripeConfig::JSON_PUBLIC_KEY->value,SaboStripeConfig::CLASSIC_ENV_PUBLIC_KEY->value,"publicKey"),
            new SaboToGet(SaboStripeConfig::JSON_SECRET_KEY->value,SaboStripeConfig::CLASSIC_ENV_SECRET_KEY->value,"secretKey"),
            new SaboToGet(SaboStripeConfig::JSON_ENDPOINT_SECRET_KEY->value,SaboStripeConfig::CLASSIC_ENV_ENDPOINT_SECRET_KEY->value,"endpointSecret"),
        );
    }

    /**
     * vérifie la signature stripe
     * @param string $eventData les données de l'évenement reçu
     * @param int $tolerance timestamp - default = 300 = 5 min
     * @return bool si la signature est bonne
     */
    public static function checkStripeSignature(string $eventData,int $tolerance = 300):bool{
        if(empty($_SERVER["HTTP_STRIPE_SIGNATURE"]) ) return false;
        
        $config = self::getConfiguration();

        if($config == null) return false;

        $endpointSecret = $config["endpointSecret"];

        $toVerify = [
            "timestamp" => "t=([^,]+)",
            "signature" => "v1=([^,]+)"
        ];

        foreach($toVerify as $variableName => $regex){
            if(!preg_match("#{$regex}#",$_SERVER["HTTP_STRIPE_SIGNATURE"],$matches) ) return false;
            
            if(empty($matches[1]) ) return false;

            // création de la variable
            $toVerify[$variableName] = $matches[1];
        }

        list("timestamp" => $timestamp,"signature" => $signature) = $toVerify;

        $signedPayload = "{$timestamp}.{$eventData}";

        $hmac = hash_hmac("sha256",$signedPayload,$endpointSecret);

        // comparaison des signatures
        if(strcmp($hmac,$signature) != 0) return false;

        $diff = time() - $timestamp;    

        return !($diff < 0 || $diff > $tolerance);
    }

    public static function manageEntrantRequest(SaboPaymentAction|string $entrantRequestManager):bool{
        $eventDatas = @file_get_contents("php://input");

        if($eventDatas == NULL || !self::checkStripeSignature($eventDatas) ) return false;

        return self::startPaymentAction($entrantRequestManager,["eventData" => $eventDatas]);
    }

    public static function getPaymentMethodName():string{
        return "carte bancaire";
    }
}