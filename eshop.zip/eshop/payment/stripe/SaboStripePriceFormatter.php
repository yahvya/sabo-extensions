<?php

namespace SaboExtensions\Eshop\Payment\Stripe;

use SaboExtensions\Eshop\Payable\SaboEshopPriceFormatter;

/**
 * formatteur de prix stripe
 */
class SaboStripePriceFormatter implements SaboEshopPriceFormatter{
    public function getFormattedPriceFrom(float $price):float{
        return round($price * 100.0,0);
    }
}