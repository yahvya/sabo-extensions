<?php

namespace SaboExtensions\Eshop\Payment\Stripe;

/**
 * configuration des clés d'api stripe
 */
enum SaboStripeConfig:string{
    /**
     * clé de récupération de l'url prefix avec fichier d'environnement json
     */
    case JSON_URL = "payment.stripe.url";

    /**
     * clé de récupération de l'url prefix avec fichier d'environnement .env
     */
    case CLASSIC_ENV_URL = "STRIPE_URL";

    /**
     * clé de récupération de la clé secrète avec fichier d'environnement json
     */
    case JSON_SECRET_KEY = "payment.stripe.secret";

    /**
     * clé de récupération de la clé secrète avec fichier d'environnement .env
     */
    case CLASSIC_ENV_SECRET_KEY = "STRIPE_SECRET_KEY";

    /**
     * clé de récupération de la clé publique avec fichier d'environnement json
     */
    case JSON_PUBLIC_KEY = "payment.stripe.public";

    /**
     * clé de récupération de la clé secrète avec fichier d'environnement .env
     */
    case CLASSIC_ENV_PUBLIC_KEY = "STRIPE_PUBLIC";

    /**
     * clé de récupération de la clé secrète webhook avec fichier d'environnement .json
     */
    case JSON_ENDPOINT_SECRET_KEY = "payment.stripe.endpoint_secret";

    /**
     * clé de récupération de la clé secrète webhook avec fichier d'environnement .env
     */
    case CLASSIC_ENV_ENDPOINT_SECRET_KEY = "STRIPE_ENDPOINT_SECRET_KEY";
}