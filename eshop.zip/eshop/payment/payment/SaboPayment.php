<?php

namespace SaboExtensions\Eshop\Payment\Payment;

use Exception;
use Sabo\Config\EnvConfig;
use Sabo\Config\SaboConfig;
use Sabo\Config\SaboConfigAttributes;
use Sabo\Controller\Controller\SaboController;
use Sabo\Mailer\SaboMailer;
use Sabo\Utils\String\RandomStringGenerator;
use Sabo\Utils\String\RandomStringType;
use SaboExtensions\Eshop\Payable\SaboEshopPriceFormatter;
use SaboExtensions\Eshop\Payable\SaboPayer;
use SaboExtensions\Eshop\Payment\Receipt\SaboDefaultReceiptCreator;
use SaboExtensions\Eshop\Payment\Receipt\SaboReceiptCreator;
use SaboExtensions\Eshop\Payment\Util\SaboPaymentApiCaller;
use SaboExtensions\Eshop\Payment\Util\SaboToGet;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

/**
 * représente un paiement
 */
abstract class SaboPayment{
    use RandomStringGenerator;

    /**
     * élements à payer tableau de SaboPayable
     */
    protected array $payables;
    
    /**
     * état du paiement
     */
    protected SaboPaymentState $paymentState;

    /**
     * aide d'appel api
     */
    protected SaboPaymentApiCaller $apiCaller;

    /**
     * formatteur de prix lié au moyen
     */
    protected SaboEshopPriceFormatter $priceFormatter;

    /**
     * dis si le paiement inclus la livraison
     */
    protected bool $includeDelivery;

    /**
     * prix de livraison
     */
    protected float $deliveryPrice;

    /**
     * promotion de livraison
     */
    protected float $deliveryDiscountPercent; 

    /**
     * promotions sur le prix total des articles
     */
    protected float $elementsToPayDiscountPercent;

    /**
     * payeur
     */
    protected SaboPayer $payer;

    /**
     * donnée finale du paiement
     * @indice elementsToPayPrice
     * @indice deliveryPrice
     * @indice payedPrice
     */
    protected array $finalPaymentData;

    /**
     * configure le moyen de paiement 
     * état du paiement mis à jour vers INITIALIZED
     * @attention méthode à appeller avant tout autre appel
     * @return bool si la configuration a réussi
     */
    abstract public function configure():bool;

    /**
     * récupère la configuration du moyen de paiement
     * @return array|null la configuration trouvé
     */
    abstract public static function getConfiguration():?array;

    /**
     * @return string le nom du moyen de paiement (carte bancaire...)
     */
    abstract public static function getPaymentMethodName():string;

    /**
     * @param SaboPayer $linkedPayer le payeur
     * @param array $payables tableau des élements à payer , de SaboPayable
     */
    public function __construct(SaboPayer $linkedPayer,array $payables){
        $this->payables = $payables;
        $this->payer = $linkedPayer;
        $this->paymentState = SaboPaymentState::UNINITIALIZED;
        $this->elementsToPayDiscountPercent = $this->deliveryDiscountPercent = $this->deliveryPrice = 0;
        $this->includeDelivery = false;
        $this->finalPaymentData = [];
    }

    /**
     * crée le reçu à partir du paiement
     * @param string $dstPath chemin de destination du fichier crée
     * @param SaboReceiptCreator $receiptCreator créateur de reçu
     * @return string|null le chemin vers le fichier crée ou null
     */
    public function createReceipt(string $dstPath,SaboReceiptCreator $receiptCreator = null):bool{
        return $receiptCreator == null ? (new SaboDefaultReceiptCreator() )->createReceipt($this,$dstPath) : $receiptCreator->createReceipt($this,$dstPath);
    }

    /**
     * défini le paiement comme incluant la livraison
     * @param float $deliveryPrice prix de livraison
     * @param float $deliveryDiscountPercent pourcentage de promotion sur la livraison
     * @return SaboPayment this
     */
    public function setAsDeliverable(float $deliveryPrice,float $deliveryDiscountPercent = 0):SaboPayment{
        $this->includeDelivery = true;

        $this->deliveryPrice = $deliveryPrice;
        $this->deliveryDiscountPercent = $deliveryDiscountPercent;

        return $this;
    }

    /**
     * serialize la class
     * @return string la class serialize
     */
    public function serialize():string{
        return serialize($this);
    }

    /**
     * @return array liste des élements à payer
     */
    public function getPayables():array{
        return $this->payables;
    }

    /**
     * @return SaboPayer le payeur
     */
    public function getPayer():SaboPayer{
        return $this->payer;
    }

    /**
     * défini la promotion sur les élements à payer
     * @return SaboPayment this
     */
    public function setElementsToPayDiscountPercent(float $discountPercent):SaboPayment{
        $this->elementsToPayDiscountPercent = $discountPercent;

        return $this;
    }

    /**
     * @return SaboEshopPriceFormatter le formatteur de prix lié au paiement
     */
    public function getPriceFormatter():SaboEshopPriceFormatter{
        return $this->priceFormatter;
    }

    /**
     * @return array les données finales du paiement
     */
    public function getFinalPaymentData():array{
        return $this->finalPaymentData;
    }

    /**
     * @return float pourcentage de réduction livraison
     */
    public function getDeliveryDiscountPercent():float{
        return $this->deliveryDiscountPercent;
    }

    /**
     * @return float pourcentage de réduction élements
     */
    public function getElementsToPayDiscount():float{
        return $this->elementsToPayDiscountPercent;
    }

    /**
     * envoie la confirmation de paiement au payeur
     * @param string $template le chemin du template twig dans le dossier template des mails
     * @param array $mailerConfig configuration de mail sabo
     * @param array $viewOtherDatas données supplémentaires destinés à la vue écrasent les données par défaut merge au niveay 1 des données
     * @param bool $setStateAsPayed met à jour le statut du paiment à payé
     * @param string|null $mailAltContent null ou contenu alternatif si null contenu alternatif par défaut utilisé
     * @param null|SaboReceiptCreator $receiptCreator créateur de reçu si null créateur par défaut utilisé
     * @attention le payer doit avoir un email attribué
     * @return bool si la confirmation à réussi
     */
    public function sendConfirmationToPayer(string $template,array $mailerConfig,array $viewOtherDatas = [],bool $setStateAsPayed = true,?string $mailAltContent = null,?SaboReceiptCreator $receiptCreator = null):bool{
        if($setStateAsPayed) $this->paymentState = SaboPaymentState::PAYED;

        $viewDatas = [
            "payment" => $this,
            "payer" => $this->payer,
            "payables" => $this->payables,
            "finalPaymentData" => $this->finalPaymentData
        ];

        // fusion simple des données
        foreach($viewOtherDatas as $key => $data ) $viewDatas[$key] = $data;

        $loader = new FilesystemLoader(ROOT . "src\\view");

        $twig = new Environment($loader,[
            "debug" => SaboConfig::getBoolConfig(SaboConfigAttributes::DEBUG_MODE)
        ]);

        // ajout des extension
        foreach(SaboController::$twigExtensions as $twigExtension) $twig->addExtension($twigExtension);

        $mailAltContent = $mailAltContent ?? $this->loadConfirmationAltContent();

        $mailer = new SaboMailer($mailerConfig);

        $receiptCreator = $receiptCreator ?? new SaboDefaultReceiptCreator();

        $root = __DIR__ . "\\..\\..\\storage\\tmp\\";

        // création du chemin de destination
        do
            $dstPath = $root . $this->generateString(20,true,RandomStringType::SPECIALCHARS) . ".pdf";
        while(file_exists($dstPath) );

        if(!$receiptCreator->createReceipt($this,$dstPath) ) return false;

        $mailer->addAttachment($dstPath,"recu.pdf");

        $sendSuccess = $mailer->sendMailFromTemplate([$this->payer->getEmail()],"Confirmation de votre paiement",$mailAltContent,$template,$viewDatas);

        unlink($dstPath);

        return $sendSuccess;
    }


    /**
     * charge le contenu alternatif du mail
     * @return string|null le contenu ou null si echec de chargement
     */
    protected function loadConfirmationAltContent():?string{
        $fileContent = @file_get_contents(__DIR__ . "\\..\\..\\storage\\confirmation-alt-content.txt");

        if($fileContent != false){
            $replacesList = [
                "payerName" => $this->payer->getPayerName(),
                "payerFname" => $this->payer->getPayerFname()
            ];

            $searches = [];
            $replaces = [];

            foreach($replacesList as $search => $value){
                array_push($searches,"{{$search}}");
                array_push($replaces,$value);
            }

            $fileContent = str_replace($searches,$replaces,$fileContent);

            return $fileContent;
        }
        
        return null;
    }

    /**
     * applique la promotion sur le pix donnée
     * @param float price
     * @param float discountPercent
     * @return float le prix final
     */
    public static function applyDiscountOn(float $price,float $discountPercent):float{
        return $price == 0 ? 0 : $price - (($price / 100) * $discountPercent);
    }

    /**
     * récupère les données à partir de la configuration
     * @param SaboToGet... $toGet représente les clés à récupérer
     * @return array|null les données indicés par les clés final toGet
     */
    public static function getDataFromConfig(SaboToGet ...$toGet):?array{
        $configDatas = EnvConfig::getConfigEnv();
        
        $datas = [];

        foreach($toGet as $getter){
            $copy = $configDatas;

            $keyParts = explode(".",EnvConfig::getIsJsonEnv() ? $getter->getKeyAsJson() : $getter->getKeyAsClassicEnv() );

            foreach($keyParts as $key){
                if(!array_key_exists($key,$copy) ) return null;

                $copy = $copy[$key];
            }

            $datas[$getter->getFinalKey()] = $copy;
        }

        return $datas;
    }

    /**
     * vérifie si les clés données sont présentes dans le tableau donnée
     * @param array $toCheck le tableau à vérifier
     * @param string ...$keys les clés
     * @return bool si les clés existent
     */
    public static function containKeys(array $toCheck,string ...$keys):bool{
        if(empty($keys) ) return false;

        foreach($keys as $key){
            $copy = $toCheck;

            $keyParts = explode(".",$key);

            foreach($keyParts as $part){
                if(!array_key_exists($part,$copy) ) return false;

                $copy = $copy[$part];
            }
        }

        return true;
    }
}