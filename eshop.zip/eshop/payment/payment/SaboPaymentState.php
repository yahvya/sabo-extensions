<?php

namespace SaboExtensions\Eshop\Payment\Payment;

/**
 * état du paiement
 */
enum SaboPaymentState{
    /**
     * paiement non initiliasé
     */
    case UNINITIALIZED;

    /**
     * paiement initialisé
     */
    case INITIALIZED;

    /**
     * en cours de paiement
     */
    case ABOUT_TO_PAY;

    /**
     * paiement fait et réussi
     */
    case PAYED;

    /**
     * paiement fait et échoué
     */
    case FAILED_TO_PAY;

    /**
     * paiement délayé à plus tard et réussie
     */
    case PAYED_FOR_LATER;

    /**
     * paiement délayé à plus tard et échoué
     */
    case FAILED_PAYED_FOR_LATER;
}