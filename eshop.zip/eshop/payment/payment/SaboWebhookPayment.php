<?php

namespace SaboExtensions\Eshop\Payment\Payment;

use Exception;
use Sabo\Config\SaboConfig;
use Sabo\Config\SaboConfigAttributes;
use SaboExtensions\Eshop\Payment\Util\SaboPaymentAction;

/**
 * représente un payment avec retour webhook
 */
abstract class SaboWebhookPayment extends SaboPayment{
    /**
     * gère les requêtes hook entrantes
     * @param SaboPaymentAction|string $entrantRequestManager class ou instance de sabopaymentaction
     * @return bool état de réussite de traitement de la requête
     * @throws Exception en mode debug en cas d'erreur
     */
    public static function manageEntrantRequest(SaboPaymentAction|string $entrantRequestManager):bool{
        return SaboWebhookPayment::startPaymentAction($entrantRequestManager);
    }

    /**
     * gère la validation du paiement
     * @recommandation server send event de validation
     * @param SaboPaymentAction|string $entrantRequestManager class ou instance de sabopaymentaction
     * @param array $params paramètres de la méthode
     * @return bool false en cas d'erreur
     * @throws Exception en mode debug en cas d'erreur
     */
    public static function validationSendEvent(SaboPaymentAction|string $entrantRequestManager,array $params = []):bool{
        return SaboWebhookPayment::startPaymentAction($entrantRequestManager,$params);
    }

    /**
     * lance l'action de l'interface passé
     * @param SaboPaymentAction|string $entrantRequestManager instance ou la class de sabopaymentaction
     * @param array $params paramètres de la méthode
     * @return bool l'état de réussite
     * @throws Exception en mode debug en cas d'erreur
     */
    protected static function startPaymentAction(SaboPaymentAction|string $entrantRequestManager,array $params = []):bool{
        if(gettype($entrantRequestManager) == "string"){
            if(!is_subclass_of($entrantRequestManager,SaboPaymentAction::class) ){
                if(!SaboConfig::getBoolConfig(SaboConfigAttributes::DEBUG_MODE) )
                    throw new Exception("{$entrantRequestManager} n'est pas une implémentation de SaboPaymentAction");
                else
                    return false;
            }

            $entrantRequestManager = new $entrantRequestManager();
        }

        return $entrantRequestManager->doAction($params);
    }
}