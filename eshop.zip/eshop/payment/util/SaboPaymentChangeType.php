<?php

namespace SaboExtensions\Eshop\Payment\Util;

/**
 * type de changement utilitaire paiement
 */
class SaboPaymentChangeType{
    /**
     * le type de changement fait
     */
    protected int $changeType;

    /**
     * @param int $changeType le type de changement 
     */
    public function __construct(int $changeType){
        $this->changeType = $changeType;
    }

    /**
     * @param int $changeType type de changement
     * @return bool si les changements sont égaux
     */
    public function matchChange(int $changeType):bool{
        return $this->changeType == $changeType;
    }    
}