<?php

namespace SaboExtensions\Eshop\Payment\Util;

/**
 * closure d'action de paiement
 */
interface SaboPaymentAction{
    /**
     * @param array $datas données supplémentaires
     * fonction appellé pour éxécuter l'action prévu
     */
    public function doAction(array $datas = []):bool;
}