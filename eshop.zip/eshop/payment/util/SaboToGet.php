<?php

namespace SaboExtensions\Eshop\Payment\Util;

/**
 * définie l'information à récupérer en fonction du type de configuration
 */
class SaboToGet{
    /**
     * clé en cas de fichier de configuration json
     */
    protected string $keyAsJson;

    /**
     * clé en cas de fichier de configuration .env
     */
    protected string $keyAsClassicEnv;

    /**
     * clé utilisé au retour de donnée
     */
    protected string $finalKey;

    /**
     * @param string $keyAsJson clé en cas de fichier de configuration json
     * @param string $keyAsClassicEnv clé en cas de fichier de configuration .env
     * @param string $finalKey clé retourné à la récupération des données
     */
    public function __construct(string $keyAsJson,string $keyAsClassicEnv,string $finalKey){
        $this->keyAsClassicEnv = $keyAsClassicEnv;
        $this->keyAsJson = $keyAsJson;
        $this->finalKey = $finalKey;
    }

    /**
     * @return string la clé en configuration .env
     */
    public function getKeyAsClassicEnv():string{
        return $this->keyAsClassicEnv;
    }

    /**
     * @return string la clé en configuration json
     */
    public function getKeyAsJson():string{
        return $this->keyAsJson;
    }

    /**
     * @return string la clé utilisé en retour
     */
    public function getFinalKey():string{
        return $this->finalKey;
    }
}