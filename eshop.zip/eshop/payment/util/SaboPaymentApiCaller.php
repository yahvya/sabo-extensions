<?php

namespace SaboExtensions\Eshop\Payment\Util;

use Sabo\Utils\Api\SaboApi;
use Sabo\Utils\Api\SaboApiRequest;

/**
 * appeleur d'api pour moyen de paiement
 */
class SaboPaymentApiCaller extends SaboApi{
    // changement de portée util
    
    public function apiUrl(string $apiSuffix):string{
        return parent::apiUrl($apiSuffix);
    }

    public function request(string $requestUrl, array $headers, mixed $data, SaboApiRequest $dataConversionType, array $overrideCurlOptions = [], ?string $storeIn = null):bool{
        return parent::request($requestUrl,$headers,$data,$dataConversionType,$overrideCurlOptions);
    }

    public function getLastRequestResult(SaboApiRequest $as):string|array|null{
        return parent::getLastRequestResult($as);
    }
}