<?php

namespace SaboExtensions\Eshop\Payment\Util;

/**
 * émétteur d'évenement sur un élement composant l'utilitaire paiement
 */
abstract class SaboPaymentChangeable{
    /**
     * compteur id unique des changeables
     */
    protected static int $changeablesId = 0;

    /**
     * id à attribué au prochain listener
     */
    protected $listenersId = 0;

    /**
     * liste de SaboPaymentListener écoutant les changements
     */
    protected array $listeners = [];

    /**
     * id attributé au changable
     */
    protected int $changeableId;

    /**
     * @attention constructeur à appeller obligatoirement
     */
    public function __construct(){
        self::$changeablesId++;

        $this->changeableId = self::$changeablesId;
    }

    /**
     * ajoute des écouteurs aux évenements
     * ajouts double impossible
     * @param SaboPaymentListener... $listeners les écouteurs
     * @return SaboPaymentChangeable this
     */
    public function addListener(SaboPaymentListener... $listeners):SaboPaymentChangeable{

        foreach($listeners as $listener){
            // vérification de non existance du listener déjà ecouté
            $isFound = false;

            $listenerId = $listener->getListenerAttributedId();

            foreach($this->listeners as $tmpListener){
                if($listenerId == $tmpListener->getListenerAttributedId() ){
                    $isFound = true;

                    break;
                }
            }

            if($isFound) continue;

            $this->listenersId++;
    
            $listener->storeListenerId($this->listenersId,$this);
            
            array_push($this->listeners,$listener);
        }

        return $this;
    }

    /**
     * supprime un listener de la liste
     * @param int|SaboPaymentListener $listener la class du listener ou l'id attribué
     * @return SaboPaymentChangeable this
     */
    public function stopBeingListened(int|SaboPaymentListener $listener):SaboPaymentChangeable{
        $listenerId = gettype($listener) == "integer" ? $listener : $listener->getListenerId($this);

        if($listenerId == null) return $this;

        foreach($this->listeners as $key => $listener){
            if($listener->getListenerId($this) == $listenerId){
                unset($this->listeners[$key]);

                $this->listeners = array_values($this->listeners);

                break;
            } 
        }   

        return $this;
    }

    /**
     * @return int l'id unique au programme attribué au changeable
     */
    public function getChangeableAttributedId():int{
        return $this->changeableId;
    }

    /**
     * émet le changement fait
     * @param SaboPaymentChangeType|int $changeType le type de changement fait id ou class de changement
     * @param mixed $previousValue valeur précédente de l'élement
     */
    protected function propagateChange(SaboPaymentChangeType|int $changeType,mixed $previousValue):SaboPaymentChangeable{
        $changeType = gettype($changeType) == "integer" ? new SaboPaymentChangeType($changeType) : $changeType;

        foreach($this->listeners as $listener) $listener->changeHappen($changeType,$previousValue,$this);

        return $this;
    }
}