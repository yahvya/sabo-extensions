<?php

namespace SaboExtensions\Eshop\Payment\Util;

/**
 * écouteur d'évenement sur un élement composant l'utilitaire paiement
 */
abstract class SaboPaymentListener{
    /**
     * compteur id unique des listener
     */
    protected static int $listenersId = 0;

    /**
     * tableau des élements écouté
     */
    protected array $listenedElements = [];

    /**
     * id attribué au listener
     */
    protected int $listenerId;

    /**
     * gère les changements fait
     * @param SaboPaymentChangeType $changeType le type de changement fait
     * @param mixed $previousValue valeur précédente du changement fait
     * @param mixed $on l'élement sur lequel le changement a été fait
     */
    abstract public function changeHappen(SaboPaymentChangeType $changeType,mixed $previousValue,mixed $on):SaboPaymentListener;

    /**
     * @attention constructeur à appeller obligatoirement
     */
    public function __construct(){
        self::$listenersId++;

        $this->listenerId = self::$listenersId;
    }

    /**
     * sauvegarde l'id attribué au listener
     * @param int $id l'id attribué
     * @param SaboPaymentChangeable $changeable le changeable
     */
    public function storeListenerId(int $id,SaboPaymentChangeable $changeable):SaboPaymentListener{ 
        $this->listenedElements[$changeable->getChangeableAttributedId()] = $id;

        return $this;
    }

    /**
     * @param SaboPaymentChangeable $changeable le changeable
     * @return int|null l'id qui a été attribué par ce changeable ou null si non trouvé
     */
    public function getListenerId(SaboPaymentChangeable $changeable):?int{
        $changeableId = $changeable->getChangeableAttributedId();

        return array_key_exists($changeableId,$this->listenedElements) ? $this->listenedElements[$changeableId] : null;
    }

    /**
     * @return int l'id attribué au listener
     */
    public function getListenerAttributedId():int{
        return $this->listenerId;
    }
}