<?php

namespace SaboExtensions\Eshop\Payment\Paypal;

use SaboExtensions\Eshop\Payable\SaboEshopPriceFormatter;

/**
 * formatteur de prix paypal
 */
class SaboPaypalPriceFormatter implements SaboEshopPriceFormatter{
    public function getFormattedPriceFrom(float $price):float{
        return round($price,2);
    }
}