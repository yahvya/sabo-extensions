<?php

namespace SaboExtensions\Eshop\Payment\Paypal;

use Closure;
use Sabo\Controller\Controller\SaboController;
use Sabo\Utils\Api\SaboApiRequest;
use SaboExtensions\Eshop\Payable\SaboPayable;
use SaboExtensions\Eshop\Payable\SaboPayer;
use SaboExtensions\Eshop\Payment\Payment\SaboPayment;
use SaboExtensions\Eshop\Payment\Payment\SaboPaymentState;
use SaboExtensions\Eshop\Payment\Util\SaboPaymentApiCaller;
use SaboExtensions\Eshop\Payment\Util\SaboToGet;

/**
 * paiement par paypal
 * @attention les élements doivent avoir la même valeur de currency
 */
class SaboPaypalPayment extends SaboPayment{
    /**
     * clé secrète paypal
     */
    protected string $secretKey;

    /**
     * id client
     */
    protected string $clientId;

    /**
     * url de retour succès
     */
    protected string $successUrl;

    /**
     * url de retour annulation
     */
    protected string $cancelUrl;

    /**
     * token authentification paypal
     */
    protected string $token;

    /**
     * id de paiement
     */
    protected string $paymentId;

    /**
     * liens de paiement
     */
    protected array $links;

    public function __construct(SaboPayer $linkedPayer,array $payables,string $successUrl,string $cancelUrl){
        parent::__construct($linkedPayer,$payables);

        $this->successUrl = $successUrl;
        $this->cancelUrl = $cancelUrl;
        $this->priceFormatter = new SaboPaypalPriceFormatter();
    }
    
    public function configure():bool{
        $configuration = self::getConfiguration();

        if($configuration == null) return false;

        list(
            "secretKey" => $this->secretKey,
            "clientId" => $this->clientId
        ) = $configuration;

        $this->apiCaller = new SaboPaymentApiCaller($configuration["url"]);
        $this->paymentState = SaboPaymentState::INITIALIZED;

        // récupération du token paypal

        $data = [
            "grant_type" => "client_credentials"
        ];
        
        $headers = [
            "Content-Type: application/x-www-form-urlencoded"
        ];
        
        $options = [
            CURLOPT_USERPWD => "{$this->clientId}:{$this->secretKey}"
        ];
 
        $callSuccess = $this->apiCaller->request(
            $this->apiCaller->apiUrl("v1/oauth2/token"),
            $headers,
            $data,
            SaboApiRequest::HTTP_BUILD_QUERY,
            $options
        );

        if(!$callSuccess) return false;

        $authenticationData = $this->apiCaller->getLastRequestResult(SaboApiRequest::RESULT_AS_JSON_ARRAY) ?? [];

        if(!self::containKeys($authenticationData,"access_token") ) return false;

        $this->token = $authenticationData["access_token"];

        return true;
    }

    /**
     * fais le paiement 
     * état du paiment mis à jour vers ABOUT_TO_PAY
     * @param array $customOptions options customisés
     * @param array $paymentDescription description du paiement
     * @param string $shippingCountryCode country code paypal utilisé si livraison affecté
     * @param Closure|null $toExecBefore closure booléene à éxécuter avant redirection
     * @return bool false si une erreur se produit
     */
    public function madePayment(string $paymentDescription,array $customOptions = [],string $shippingCountryCode = "FR",?Closure $toExecBefore = null):bool{
        if(empty($this->payables) ) return false;

        $totalPrice = 0;
        
        $order = $this->createOrder($totalPrice);

        if($totalPrice == 0) return false;

        // récupération de la valeur de promotion des articles et prix de livraison
        $discountValue = $this->priceFormatter->getFormattedPriceFrom($this->elementsToPayDiscountPercent == 0 ? 0 : (($totalPrice / 100) * $this->elementsToPayDiscountPercent) );
        $deliveryPrice = $this->priceFormatter->getFormattedPriceFrom($this->deliveryDiscountPercent == 0 || (!$this->includeDelivery) ? $this->deliveryPrice : self::applyDiscountOn($this->deliveryPrice,$this->deliveryDiscountPercent) );

        $currency = strtoupper($this->payables[0]->getCurrency()->getPaymentMethodCurrency() );

        $payedPrice = $this->priceFormatter->getFormattedPriceFrom($totalPrice + $deliveryPrice - $discountValue);

        // corps paypal
        $data = [
            "intent" => "CAPTURE",
            "purchase_units" => [
                [
                    "description" => $paymentDescription,
                    "items" => $order,
                    "amount" => [
                        "currency_code" => $currency,
                        "value" => $payedPrice,
                        "breakdown" => [
                            "item_total" => [
                                "currency_code" => $currency,
                                "value" => $totalPrice
                            ],
                            "shipping" => [
                                "currency_code" => $currency,
                                "value" => $deliveryPrice
                            ],
                            "discount" => [
                                "currency_code" => $currency,
                                "value" => $discountValue
                            ]
                        ]
                    ]
                ]
            ],
            "application_context" => [
                "landing_page" => 'NO_PREFERENCE',
                "return_url" => $this->successUrl,
                "cancel_url" => $this->cancelUrl
            ]
        ];

        // ajout de la livraison
        if($this->includeDelivery){
            $data["purchase_units"][0]["shipping"] = [
                "type" => "SHIPPING",
                "name" => [
                    "full_name" => "{$this->payer->getPayerName()} {$this->payer->getPayerFname()}"
                ]
            ];

            if($this->payer->getHaveAddress() ){

                $data["purchase_units"][0]["shipping"]["address"] = [
                    "address_line_1" => $this->payer->getAddress(),
                    "address_line_2" => $this->payer->getAddressComplement() ?? "",
                    "admin_area_2" => $this->payer->getCity(),
                    "postal_code" => $this->payer->getPostalCode(),
                    "country_code" => $shippingCountryCode
                ];

                $data["application_context"]["shipping_preference"] = "SET_PROVIDED_ADDRESS";
            }
        }

        $data = array_merge_recursive($data,$customOptions);

        $headers = [
            "Authorization:Bearer {$this->token}",
            "Content-Type:application/json"
        ];

        $callSuccess = $this->apiCaller->request(
            $this->apiCaller->apiUrl("v2/checkout/orders"),
            $headers,
            $data,
            SaboApiRequest::JSON_BODY
        );

        if(!$callSuccess) return false;

        $paymentData = $this->apiCaller->getLastRequestResult(SaboApiRequest::RESULT_AS_JSON_ARRAY) ?? [];

        if(!self::containKeys($paymentData,"id","links") ) return false;

        $this->paymentId = $paymentData["id"];
        $this->links = [];

        // récupération des liens de paiement
        foreach(["self","approve","capture"] as $toFind){
            foreach($paymentData["links"] as $linkData){
                if($linkData["rel"] == $toFind){
                    $this->links[$toFind] = $linkData["href"];

                    break;
                }
            }
        }

        if(!self::containKeys($this->links,"capture","approve","self") ) return false;

        $this->paymentState = SaboPaymentState::ABOUT_TO_PAY;
        $this->finalPaymentData = [
            "elementsToPayPrice" => $totalPrice,
            "deliveryPrice" => $deliveryPrice,
            "payedPrice" => $payedPrice
        ];

        if($toExecBefore != null && !$toExecBefore() ) return false;

        SaboController::redirectToLink($this->links["approve"]);
        
        return false;
    }

    /**
     * crée les payables au format paypal
     * @param float $totalPrice conteneur prix total
     * @return array les payables crées
     */
    protected function createOrder(float &$totalPrice):array{
        $currency = strtoupper($this->payables[0]->getCurrency()->getPaymentMethodCurrency() );

        $totalPrice = 0;

        $order = array_map(function(SaboPayable $payable)use($currency,&$totalPrice):array{
            $totalPrice += $payable->getFormattedPrice($this->priceFormatter);

            return [
                "name" => $payable->getElementName() ?? "Produit",
                "quantity" => $payable->getQuantity(),
                "unit_amount" => [
                    "currency_code" => $currency,
                    "value" => $payable->getSingleFormattedPrice($this->priceFormatter)
                ]
            ];
        },$this->payables);

        $totalPrice = $this->priceFormatter->getFormattedPriceFrom($totalPrice);

        return $order;
    }

    /**
     * met à jour l'url cancel
     * @param string $successUrl l'url success
     * @return SaboPaypalPayment this
     */
    public function setCancelUrl(string $cancelUrl):SaboPaypalPayment{
        $this->cancelUrl = $cancelUrl;
        
        return $this;
    }

    /**
     * met à jour l'url cancel
     * @param string $successUrl l'url success
     * @return SaboPaypalPayment this
     */
    public function setSuccessUrl(string $successUrl):SaboPaypalPayment{
        $this->successUrl = $successUrl;
        
        return $this;
    }

    /**
     * @return string le token 
     */
    public function getToken():string{
        return $this->token;
    }

    /**
     * @return array les liens
     */
    public function getLinks():array{
        return $this->links;
    }

    /**
     * vérifie si l'état du paiement est completé
     * @param string $accessToken le token retourné par paypal (à comparé en amont avec le token recupéré après la configuration $this->getToken() )
     * @param string $linkedLink le lien de capture récupéré en amont via $this->getLinks()
     */
    public static function confirmPayment(string $accessToken,string $linkedLink):bool{
        $configuration = self::getConfiguration();

        if($configuration == null) return false;

        $apiCaller = new SaboPaymentApiCaller($configuration["url"]);

        $headers = [
			"Content-type: application/json",
			"Authorization: Bearer {$accessToken}"
		];

        $callSuccess = $apiCaller->request($linkedLink,$headers,null,SaboApiRequest::NO_DATA,[CURLOPT_POST => true]);

		if($callSuccess){
            $result = $apiCaller->getLastRequestResult(SaboApiRequest::RESULT_AS_JSON_ARRAY) ?? [];

			return self::containKeys($result,"status") && $result["status"] == "COMPLETED";
		}

		return false;
    }

    /**
     * @indice url
     * @indice clientId
     * @indice secretKey
     */
    public static function getConfiguration():?array{
        return self::getDataFromConfig(
            new SaboToGet(SaboPaypalConfig::JSON_URL->value,SaboPaypalConfig::CLASSIC_ENV_URL->value,"url"),
            new SaboToGet(SaboPaypalConfig::JSON_CLIENT_ID->value,SaboPaypalConfig::CLASSIC_ENV_CLIENT_ID->value,"clientId"),
            new SaboToGet(SaboPaypalConfig::JSON_SECRET_KEY->value,SaboPaypalConfig::CLASSIC_ENV_SECRET_KEY->value,"secretKey")
        );
    }

    public static function getPaymentMethodName():string{
        return "paypal";
    }
}