<?php

namespace SaboExtensions\Eshop\Payment\Paypal;

/**
 * configuration des clés d'api paypal
 */
enum SaboPaypalConfig:string{
    /**
     * clé de récupération de l'url prefix avec fichier d'environnement json
     */
    case JSON_URL = "payment.paypal.url";

    /**
     * clé de récupération de l'url prefix avec fichier d'environnement .env
     */
    case CLASSIC_ENV_URL = "PAYPAL_URL";

    /**
     * clé de récupération de la clé clien dans un fichier de configuration .json
     */
    case JSON_CLIENT_ID = "payment.paypal.client_id";

    /**
     * clé de récupération de la clé clien dans un fichier de configuration .env
     */
    case CLASSIC_ENV_CLIENT_ID = "PAYPAL_CLIENT_ID"; 

    /**
     * clé de récupération de la clé clien dans un fichier de configuration .json
     */
    case JSON_SECRET_KEY = "payment.paypal.secret_key";

    /**
     * clé de récupération de la clé clien dans un fichier de configuration .env
     */
    case CLASSIC_ENV_SECRET_KEY = "PAYPAL_SECRET_KEY"; 
}