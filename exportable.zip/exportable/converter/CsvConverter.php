<?php

namespace SaboExtensions\Exportable\Converter;

/**
 * convertisseur csv
 */
abstract class CsvConverter{
    /**
     * converti le tableau sous format chaine csv
     * @param array $toConvert le tableau à convertir
     * @return string|null la chaine csv ou null
     */
    public static function convert(array $toConvert):?string{
        $csvString = "";
        
        foreach($toConvert as $line){
            if(gettype($line) != "array") return null;

            $csvString .= @implode(",",$line) . "\n";
        }

        return $csvString;
    }
}