<?php

namespace SaboExtensions\Exportable\Config;

/**
 * type de formattage d'export et d'import
 */
enum ExportableType{
    /**
     * type par défaut donnée convertis en fichier json
     * @format tableau classique php
     */
    case JSON;

    /**
     * converti les données au format csv
     * @format [ [col1,col2,col3],[col1,col2,col3] ]
     * modification possible en modifiant la gestion via CsvConverter
     */
    case CSV;

    /**
     * mode de conversion customisé pour utiliser
     * @format ["convertedData" => "votre_donnee_converti"]
     */
    case CUSTOM;
}