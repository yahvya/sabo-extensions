<?php

namespace SaboExtensions\Exportable\Config;

/**
 * type d'export
 */
enum ExportAs{
    /**
     * exporte le(s) éléments sous forme de zip
     */
    case ZIP;

    /**
     * exporte l'élement dans un fichier si plusieurs fichiers sont fournies un dossier les contenants sera crée
     */
    case FILE;
}