<?php

namespace SaboExtensions\Exportable\Exportable;

use SaboExtensions\Exportable\ExportablePath\ExportablePathFinder;

/**
 * élément à exporter
 */
class ToExport{
    /**
     * élement à exporter
     */
    protected Exportable $exportable;

    /**
     * récupérateur de chemin
     */
    protected ?ExportablePathFinder $pathFinder;

    /**
     * @param Exportable $exportable l'élément à exporter
     * @param ExportablePathFinder $pathFinder le gestionnaire de chemin de l'élement
     */
    public function __construct(Exportable $exportable,ExportablePathFinder $pathFinder){
        $this->exportable = $exportable;
        $this->pathFinder = $pathFinder;
    }

    /**
     * @return Exportable l'exportable lié
     */
    public function getExportable():Exportable{
        return $this->exportable;
    }

    /**
     * @return ExportablePathFinder le gestionnaire de chemin
     */
    public function getPathFinder():ExportablePathFinder{
        return $this->pathFinder;
    }
}