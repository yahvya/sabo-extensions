<?php

namespace SaboExtensions\Exportable\Exportable;

use SaboExtensions\Exportable\Config\ExportableType;
use SaboExtensions\Exportable\Config\ExportAs;
use SaboExtensions\Exportable\Converter\CsvConverter;
use SaboExtensions\Exportable\ExportablePath\ExportablePathFinder;
use ZipArchive;

/**
 * gestionnaire d'élements exportable
 */
abstract class ExportableManager{
    /**
     * espace de stockage interne de l'extension
     */
    public const STORAGE_PATH = __DIR__ . "\\..\\storage\\";

    /**
     * crée les éléments exportés 
     * @param ExportAs $as configuration de sauvegarde
     * @param ToExport ...$elementsToExport élements à exporter
     * @return string|null le chemin de l'élément à exporter
     */
    public static function export(ExportAs $as,ToExport ...$elementsToExport):?string{
        if(empty($elementsToExport) ) return null;

        switch($as){
            case ExportAs::FILE:
                return self::exportAsFile(...$elementsToExport);    
            ;

            case ExportAs::ZIP:
                return self::exportAsZip(...$elementsToExport);    
            ; 

            default:
                return null;
            ;
        }
    }

    /**
     * exporte les élements en tant que fichier
     * @param ToExport...$elementsToExport élements à exporter
     * @return string|null le chemin de l'élement
     */
    protected static function exportAsFile(ToExport... $elementsToExport):?string{
        if(count($elementsToExport) > 1){
            // création d'un dossier     
            $dirPath = self::STORAGE_PATH . ExportablePathFinder::getFreeDirname(self::STORAGE_PATH) . "\\";

            if(!@mkdir($dirPath) )  return null;

            // ajout des élements dans le dossier crée
            foreach($elementsToExport as $toExport){
                $toExport->getPathFinder()->setDirPath($dirPath);

                if(self::saveExportable($toExport) == null){
                    ExportablePathFinder::deleteDir($dirPath);
                    
                    return null;
                }
            }

            return $dirPath;
        }
        else return self::saveExportable($elementsToExport[0]);
    }

    /**
     * exporte les élements en tant que zip
     * @param ToExport...$elementsToExport élements à exporter
     * @return string|null le chemin chemin de l'élement
     */
    protected static function exportAsZip(ToExport... $elementsToExport):?string{
        if(count($elementsToExport) == 1){
            // création d'un dossier à un élément
            $path = self::STORAGE_PATH . ExportablePathFinder::getFreeDirname(self::STORAGE_PATH) . "\\";

            if(!@mkdir($path) ) return false;

            $elementsToExport[0]->getPathFinder()->setDirPath($path);

            if(self::exportAsFile($elementsToExport[0]) == null){
                ExportablePathFinder::deleteDir($path);

                return null;
            }
        }
        else{
            // création de dossier implicite par appel à plus d'un élement
            $path = self::exportAsFile(...$elementsToExport);

            if($path == null) return null;
        }

        // création du zip en remplacement du dossier
        $zip = new ZipArchive();
    
        $zipPath = self::STORAGE_PATH . ExportablePathFinder::getFreeFilename(self::STORAGE_PATH,".zip") . ".zip";

        if(!@$zip->open($zipPath,ZipArchive::CREATE) ) return false;

        // ajout des fichiers du dossier au zip
        foreach($elementsToExport as $toExport){
            $pathFinder = $toExport->getPathFinder();

            $name = "{$pathFinder->getFilename()}{$pathFinder->getExtension()}";

            $zip->addFile("{$path}{$name}",$name);
        }

        if(!$zip->close() ){
            @unlink($zipPath);

            return null;
        }

        ExportablePathFinder::deleteDir($path);

        return $zipPath;
    }

    /**
     * récupère la version converti de l'exportable
     * @param Exportable $exportable l'élément exportable
     * @return string|null la donnée ou null en cas d'erreur
     */
    protected static function getExportableData(Exportable $exportable):?string{
        $toExportData = $exportable->export();

        if($toExportData === null) return null;

        // conversion et récupération des données
        switch($exportable->getExportableType() ){
            case ExportableType::CSV:
                return CsvConverter::convert($toExportData);
            ; break;

            case ExportableType::JSON:
                $jsonData = @json_encode($toExportData,JSON_PRETTY_PRINT);

                if($jsonData != false) return $jsonData;
            ; break;

            case ExportableType::CUSTOM:
                if(array_key_exists("convertedData",$toExportData) ) return $toExportData["convertedData"];
            ; break;
        }

        return null;
    }

    /**
     * sauvegarde l'élement à exporter dans le chemin
     * @param ToExport $toExport l'élement à exporter
     * @return string|null le chemin de l'export ou null
     */
    protected static function saveExportable(ToExport $toExport):?string{
        $exportableContent = self::getExportableData($toExport->getExportable() );

        if($exportableContent == null) return null;

        $path = $toExport->getPathFinder()->generatePath();

        return $path != null && @file_put_contents($path,$exportableContent) !== false ? $path : null;
    }
}