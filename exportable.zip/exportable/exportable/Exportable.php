<?php

namespace SaboExtensions\Exportable\Exportable;

use SaboExtensions\Exportable\Config\ExportableType;

/**
 * élément exportable
 */
interface Exportable{
    /**
     * exporte les données de l'élement
     * @return array|null l'élement sous forme de tableau utilisable en fonction de la configuration ou null si exportation échoué
     */
    public function export():?array;

    /**
     * importe l'élement à partir de la donnée reformaté
     * @param array $datas la donnée
     * @return bool si l'importable à réussi
     */
    public static function importFrom(array $datas):bool;

    /**
     * @return ExportableType le type de formattage
     */
    public static function getExportableType():ExportableType;
}