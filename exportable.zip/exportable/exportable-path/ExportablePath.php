<?php

namespace SaboExtensions\Exportable\ExportablePath;

/**
 * configuration de la récupération de chemin
 */
interface ExportablePath{
    /**
     * @return string|null le chemin crée ou null en cas d'erreur
     */
    public function generatePath():?string;
}