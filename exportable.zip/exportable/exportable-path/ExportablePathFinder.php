<?php

namespace SaboExtensions\Exportable\ExportablePath;

use Sabo\Utils\String\RandomStringGenerator;
use Sabo\Utils\String\RandomStringType;
use SaboExtensions\Exportable\Exportable\ExportableManager;

/**
 * représente un chemin à récupérer
 */
class ExportablePathFinder implements ExportablePath{
    use RandomStringGenerator;

    /**
     * élement avec dossier destiné à ne pas être utilisé (exportation zip)
     */
    public const EMPTY_DIR_PATH = "";

    /**
     * taille maximum d'un chemin de fichier
     */
    protected const FILE_MAX_LEN = 230;

    /**
     * taille maximum d'un chemin de dossier
     */
    protected const DIR_FILE_MAX_LEN = 150;

    /**
     * le chemin du dossier de l'élement - dossier existant
     */
    protected ?string $dirPath;

    /**
     * nom du fichier sans extension
     */
    protected ?string $filename;

    /**
     * l'extension du fichier
     */
    protected string $extension;

    /**
     * @param string $dirPath chemin du dossier parent ou null
     * @param string $extension extension du fichier incluant le .
     * @param string|null $filename le nom du fichier ou null si le nom doit être généré
     */
    public function __construct(?string $dirPath,string $extension,?string $filename = null){
        $this->dirPath = $dirPath;
        $this->extension = $extension;
        $this->filename = $filename;
    }

    /**
     * met à jour le chemin du dossier
     * @param string|null $dirPath le chemin du dossier ou null
     * @return ExportablePathFinder this
     */
    public function setDirPath(?string $dirPath):ExportablePathFinder{
        $this->dirPath = $dirPath;

        return $this;
    }

    /**
     * met à jour le nom du fichier
     * @param string|null $filename le nom du fichier ou null si la valeur doit être généré
     * @return ExportablePathFinder this
     */
    public function setFilename(?string $filename):ExportablePathFinder{
        $this->filename = $filename;

        return $this;
    }

    /**
     * met à jour l'extension
     * @param string $extension l'extension
     * @return ExportablePathFinder this
     */
    public function setExtension(string $extension):ExportablePathFinder{
        $this->extension = $extension;

        return $this;
    }

    /**
     * @return string|null le chemin du dossier
     */
    public function getDirPath():?string{
        return $this->dirPath;
    }

    /**
     * @return string|null le nom du fichier affecté ou null
     */
    public function getFilename():?string{
        return $this->filename;
    }

    /**
     * @return string l'extension du fichier
     */
    public function getExtension():string{
        return $this->extension;
    }

    public function generatePath():?string{
        if($this->dirPath == null) $this->dirPath = ExportableManager::STORAGE_PATH;

        $filename = $this->filename ?? self::getFreeFilename($this->dirPath,$this->extension);

        $this->filename = $filename;

        if(!is_dir($this->dirPath) || $this->filename == null) return null;

        if(!str_ends_with($this->dirPath,"/") && !str_ends_with($this->dirPath,"\\") ) $this->dirPath .= "\\";

        return "{$this->dirPath}{$this->filename}{$this->extension}";
    } 

    /**
     * génère un nom de fichier libre dans le dossier donné avec l'extension
     * @param string $dirPath nom d'un dossier existant
     * @param string $extension l'extension du fichier
     * @param int|null $customMaxLen taille maximum du chemin si null alors valeur par défaut utilisé
     * @return string|null le nom du fichier trouvé ou null
     */
    public static function getFreeFilename(string $dirPath,string $extension,?int $customMaxLen = null):?string{
        if(!is_dir($dirPath) ) return null;

        if(!str_ends_with($dirPath,"/") && !str_ends_with($dirPath,"\\") ) $dirPath .= "\\";

        $customMaxLen = $customMaxLen ?? self::FILE_MAX_LEN;

        $len = $customMaxLen - (strlen($dirPath) + strlen($extension) );
        
        if($len < 1) return null;

        do
            $filename = self::generateString($len,true,RandomStringType::NUMBERS,RandomStringType::SPECIALCHARS,RandomStringType::UPPERCHARS);
        while(file_exists("{$dirPath}{$filename}{$extension}") );

        return $filename;
    }

    /**
     * génère un nom de dossier libre dans le dossier donnée
     * @param string $dirPath chemin du dossier conteneur
     * @param int|null $customMaxLen taille maximum du chemin si null alors valeur par défaut utilisé
     * @return string|null le nom crée
     */
    public static function getFreeDirname(string $dirPath,?int $customMaxLen = null):?string{
        if(!is_dir($dirPath) ) return null;

        if(!str_ends_with($dirPath,"/") && !str_ends_with($dirPath,"\\") ) $dirPath .= "\\";

        $customMaxLen = $customMaxLen ?? self::DIR_FILE_MAX_LEN;

        $len = $customMaxLen - strlen($dirPath);
        
        if($len < 1) return null;

        do
            $dirname = self::generateString($len,true,RandomStringType::NUMBERS,RandomStringType::SPECIALCHARS,RandomStringType::UPPERCHARS);
        while(is_dir("{$dirPath}{$dirname}") );

        return $dirname;
    }

    /**
     * supprime un dossier
     * @param string $dir le chemin du dossier
     */
    public static function deleteDir(string $dir):void{ 
        if(is_dir($dir) ){
            if(!str_ends_with($dir,"\\") && !str_ends_with($dir,"/") ) $dir .= "\\";

            $dirElementsList = array_diff(scandir($dir),[".",".."]);

            foreach($dirElementsList as $dirElement) self::deleteDir($dir . $dirElement);

            @rmdir($dir);
        }
        else @unlink($dir);
    }
}